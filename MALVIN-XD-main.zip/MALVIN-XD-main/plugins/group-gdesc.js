const config = require('../settings')
const { malvin } = require('../malvin')

malvin({
    pattern: "updategdesc",
    alias: ["upgdesc", "gdesc"],
    react: "📜",
    desc: "Modifie la description du groupe avec autorité.",
    category: "groupe",
    filename: __filename
},           
async (conn, mek, m, { from, isGroup, isAdmins, isBotAdmins, q, reply }) => {
    try {
        if (!isGroup) return reply("❌ Cette invocation n’est possible qu’en groupe.");
        if (!isAdmins) return reply("❌ Seuls les seigneurs (admins) peuvent changer la description.");
        if (!isBotAdmins) return reply("❌ Je dois être admin pour imposer ma volonté sur la description.");
        if (!q) return reply("❌ Tu dois fournir une nouvelle description, ô maître.");

        await conn.groupUpdateDescription(from, q);
        reply("✅ La description du groupe a été changée. Que le pouvoir règne !");
    } catch (e) {
        console.error("❌ Erreur lors de la mise à jour de la description :", e);
        reply("❌ Échec de la mise à jour. Le chaos persiste...");
    }
});