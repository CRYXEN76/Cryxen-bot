const { malvin } = require('../malvin');
const axios = require('axios');

malvin({
    pattern: "countryinfo",
    alias: ["cinfo", "country", "cinfo2"],
    desc: "Obtenir des informations détaillées sur un pays.",
    category: "other",
    react: "🌍",
    filename: __filename
},
async (conn, mek, m, { from, args, q, reply, react }) => {
    try {
        if (!q) return reply("❌ Indique le nom d'un pays.\nExemple : `.countryinfo France`");

        const apiUrl = `https://api.siputzx.my.id/api/tools/countryInfo?name=${encodeURIComponent(q)}`;
        const { data } = await axios.get(apiUrl);

        if (!data.status || !data.data) {
            await react("❌");
            return reply(`⚠️ Aucune information trouvée pour *${q}*. Vérifie bien le nom.`);
        }

        const info = data.data;

        const voisins = (info.neighbors.length > 0)
            ? info.neighbors.map(n => `🌍 *${n.name}*`).join(", ")
            : "Aucun pays voisin détecté.";

        const texte = `
╔═✪ *INFOS PAYS - CRYXEN 𝕏* ✪═╗
║🌐 *Nom:* ${info.name}
║🏛 *Capitale:* ${info.capital}
║📍 *Continent:* ${info.continent.name} ${info.continent.emoji}
║📞 *Indicatif téléphonique:* +${info.phoneCode}
║📏 *Superficie:* ${info.area.squareKilometers} km² (${info.area.squareMiles} mi²)
║🚗 *Côté de conduite:* ${info.drivingSide}
║💰 *Monnaie:* ${info.currency}
║🗣 *Langues:* ${info.languages.native.join(", ")}
║🌟 *Connu pour:* ${info.famousFor}
║🔢 *Codes ISO:* ${info.isoCode.alpha2.toUpperCase()}, ${info.isoCode.alpha3.toUpperCase()}
║🌐 *Domaine internet:* ${info.internetTLD}
╚═✪ *Voisins:* ${voisins} ═╝
        `.trim();

        await conn.sendMessage(from, {
            image: { url: info.flag },
            caption: texte,
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: mek });

        await react("✅");
    } catch (e) {
        console.error("Erreur commande countryinfo:", e);
        await react("❌");
        reply("❌ Une erreur est survenue lors de la récupération des infos du pays.");
    }
});