const { malvin } = require('../malvin');

malvin({
    pattern: "hack",
    desc: "Commande diabolique pour simuler un piratage sombre et stylé.",
    category: "fun",
    filename: __filename
},
async (conn, mek, m, { senderNumber, reply }) => {
    try {
        const botOwner = conn.user.id.split(":")[0];
        if (senderNumber !== botOwner)
            return reply("⛔ *Accès refusé ! Seul le maître des ténèbres peut exécuter cette commande.*");

        const étapes = [
            '☠️ *INITIATION DU RITUEL DE HACKING...* ☠️',
            '🔪 *Chargement des armes numériques...* ⚔️',
            '🌑 *Connexion à l\'ombre du réseau noir...* 🕸️',
            '```[█□□□□□□□□□] 10% - Enfoncement du croc dans le système```',
            '```[███□□□□□□□] 30% - Infiltration des démons binaires```',
            '```[█████□□□□□] 50% - Brèche dans le pare-feu de l\'enfer```',
            '```[███████□□□] 70% - Extraction des âmes du système```',
            '```[█████████□] 90% - Déchirement des protocoles sacrés```',
            '```[██████████] 100% - Domination absolue atteinte```',
            '🔥 *🔥 SYSTÈME COMPROMIS - LE FEU NOIR RAVAGE TOUT 🔥*',
            '💀 *Exécution des rituels finaux...* ☠️',
            '*📡 Envoi des données vers le néant...* 🌌',
            '_🕵️‍♂️ Effacement des traces - silence éternel..._ 🌑',
            '*⚙️ Rituel finalisé - le chaos règne désormais.* 👹',
            '⚠️ *⚠️ Ceci n’est qu’un jeu maléfique. N’essayez pas cela chez vous.*',
            '> *⛓️ HACK TERMINÉ - LE MAL S’EST ABATTU ⛓️*'
        ];

        for (const ligne of étapes) {
            await reply(ligne);
            await new Promise(r => setTimeout(r, Math.random() * 1000 + 700));
        }
    } catch (e) {
        console.error(e);
        reply("💥 Une erreur infernale est survenue : " + e.message);
    }
});