const { malvin } = require('../malvin');

// 📛 Blocage d’un utilisateur par le Maître
malvin({
    pattern: "block",
    desc: "⚔️ Invoque la puissance de CRYXEN 𝕏 pour bannir un contact",
    category: "owner",
    react: "🚫",
    filename: __filename
}, async (conn, m, { reply, q, react }) => {
    const botOwner = conn.user.id.split(":")[0] + "@s.whatsapp.net";

    if (m.sender !== botOwner) {
        await react("❌");
        return reply("🛑 Seul le maître 𝙲𝚁𝚈𝚇𝙴𝙽²¹⁰⁹ peut exécuter cette sentence.");
    }

    let jid;
    if (m.quoted) {
        jid = m.quoted.sender;
    } else if (m.mentionedJid.length > 0) {
        jid = m.mentionedJid[0];
    } else if (q && q.includes("@")) {
        jid = q.replace(/[@\s]/g, '') + "@s.whatsapp.net";
    } else {
        await react("❌");
        return reply("⚠️ Mentionne une cible ou réponds à son message pour la condamner.");
    }

    try {
        await conn.updateBlockStatus(jid, "block");
        await react("✅");
        reply(`🚫 *L'utilisateur @${jid.split("@")[0]} a été banni du royaume CRYXEN 𝕏 !*`, { mentions: [jid] });
    } catch (error) {
        console.error("❌ Erreur dans la commande block :", error);
        await react("❌");
        reply("❌ Échec de la sentence, l'ombre a résisté.");
    }
});

// 🔓 Déblocage d’un utilisateur par CRYXEN 𝕏
malvin({
    pattern: "unblock",
    desc: "🔓 Libère une cible de l’emprise de CRYXEN 𝕏",
    category: "owner",
    react: "🔓",
    filename: __filename
}, async (conn, m, { reply, q, react }) => {
    const botOwner = conn.user.id.split(":")[0] + "@s.whatsapp.net";

    if (m.sender !== botOwner) {
        await react("❌");
        return reply("🛑 Seul le Maître CRYXEN 𝕏 peut briser les chaînes.");
    }

    let jid;
    if (m.quoted) {
        jid = m.quoted.sender;
    } else if (m.mentionedJid.length > 0) {
        jid = m.mentionedJid[0];
    } else if (q && q.includes("@")) {
        jid = q.replace(/[@\s]/g, '') + "@s.whatsapp.net";
    } else {
        await react("❌");
        return reply("⚠️ Mentionne une cible ou réponds à son message pour la libérer.");
    }

    try {
        await conn.updateBlockStatus(jid, "unblock");
        await react("✅");
        reply(`🔓 *L'utilisateur @${jid.split("@")[0]} est désormais libre. CRYXEN 𝕏 a levé la sentence.*`, { mentions: [jid] });
    } catch (error) {
        console.error("❌ Erreur dans la commande unblock :", error);
        await react("❌");
        reply("❌ Échec du déblocage. Quelque chose résiste dans les ténèbres.");
    }
});