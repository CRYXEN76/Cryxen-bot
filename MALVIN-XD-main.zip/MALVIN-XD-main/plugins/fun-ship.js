const { malvin } = require("../malvin");
const config = require("../settings");

malvin({
  pattern: "ship",
  alias: ["match", "love"],
  desc: "Associe deux âmes perdues dans le chaos du groupe.",
  react: "🩸",
  category: "fun",
  filename: __filename
}, async (conn, m, store, { from, isGroup, groupMetadata, reply, sender }) => {
  try {
    if (!isGroup) return reply("🚫 Cette malédiction ne s’invoque qu’en groupe.");

    const specialNumber = config.DEV ? `${config.DEV}@s.whatsapp.net` : null;
    const participants = groupMetadata.participants.map(u => u.id);

    let target;

    if (specialNumber && participants.includes(specialNumber) && sender !== specialNumber) {
      target = specialNumber;
    } else {
      do {
        target = participants[Math.floor(Math.random() * participants.length)];
      } while (target === sender);
    }

    const pourcent = Math.floor(Math.random() * 100) + 1;
    const darkLove = `
╭──〔 💔 𝙿𝙰𝙸𝚁𝙰𝙶𝙴 𝙳𝙴́𝙼𝙾𝙽𝙸𝙰𝚀𝚄𝙴 💔 〕──
│
│ ☠️ Âme n°1 : @${sender.split("@")[0]}
│ 🔥 Damnée à aimer...
│ ☠️ Âme n°2 : @${target.split("@")[0]}
│
│ 💉 Compatibilité maudite : *${pourcent}%*
│ 🕯️ Pacte scellé sous l'œil de CRYXEN 𝕏
╰⛧━━━━━━━⛧

*🕷️ Que les flammes de l’enfer bénissent votre union.*`.trim();

    await conn.sendMessage(from, {
      text: darkLove,
      contextInfo: {
        mentionedJid: [sender, target],
        forwardingScore: 0,
        isForwarded: false
      }
    });

  } catch (e) {
    console.error("💥 Erreur démoniaque :", e);
    reply("☠️ Une force obscure a bloqué l'invocation.");
  }
});