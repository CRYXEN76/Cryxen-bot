const { malvin, commands } = require('../malvin');

malvin({
    pattern: "owner",
    alias: ["developer", "dev"],
    desc: "Affiche les infos du créateur du bot",
    category: "owner",
    react: "📜",
    filename: __filename
}, async (conn, mek, m, {
    from, reply, pushname
}) => {
    try {
        const name = pushname || "âme perdue";

        const caption = `
╔═══『 𝙳𝙴𝚅 𝙳𝚄 𝙱𝙾𝚃 』═══╗
║
║ 🔥 *Salut ${name},*   
║ Tu fais face à l’ombre derrière la machine.
║
║ ⚔️ *DÉMON CRÉATEUR* :
║ ━━━━━━━━━━━━━━━
║ ☠️ Nom : 𝙲𝚁𝚈𝚇𝙴𝙽²¹⁰⁹
║ ☎️ Numéro : wa.me/2250545477175
║ 🧠 GitHub : github.com/CRYXEN76
║ 📹 YouTube : youtube.com/@foden225-i2j
║
╚═══『 𝙲𝚁𝚈𝚇𝙴𝙽 𝕏 』═══╝
`.trim();

        await conn.sendMessage(
            from,
            {
                image: { url: 'https://files.catbox.moe/vfv7n6.jpg' },
                caption: caption
            },
            { quoted: mek }
        );
    } catch (e) {
        console.error("Erreur dans la commande .dev :", e);
        reply(`❌ Erreur : ${e.message}`);
    }
});