const config = require('../settings');
const { malvin } = require('../malvin');
const { getGroupAdmins } = require('../lib/functions');

malvin({
  pattern: "tagall",
  alias: ["gc_tagall"],
  desc: "Invoque chaque âme du groupe avec un message personnalisé.",
  category: "group",
  use: ".tagall ⚠️ L'heure du rassemblement a sonné...",
  react: "👁️",
  filename: __filename,
},
async (conn, mek, m, {
  from, isGroup, senderNumber, participants, reply, command, body, groupAdmins
}) => {
  try {
    if (!isGroup)
      return reply("⛔ *Ce sort ne peut être lancé que dans un groupe.*");

    const senderJid = m.sender;
    const botOwner = conn.user.id.split(":")[0] + "@s.whatsapp.net";

    if (!groupAdmins.includes(senderJid) && senderJid !== botOwner)
      return reply("🔐 *Tu n’es pas digne d’invoquer la horde. Admins ou Maître Suprême uniquement.*");

    const metadata = await conn.groupMetadata(from).catch(() => null);
    if (!metadata)
      return reply("💀 *Le néant empêche l'accès aux informations du groupe.*");

    const groupName = metadata.subject || "Groupe Sans Nom";
    const totalMembers = participants?.length || 0;

    if (!totalMembers)
      return reply("👻 *Aucune âme trouvée à marquer.*");

    const glyphs = ['🩸', '🕯️', '🧿', '👁️', '⚔️', '🔥', '🧛', '🪓', '🕷️', '☠️'];
    const glyph = glyphs[Math.floor(Math.random() * glyphs.length)];

    const msg = body.slice(body.indexOf(command) + command.length).trim() || "⚠️ *L'invocation a commencé...*";

    let text = `
╭─────⊰⚰️⊱─────╮
┃ ✦ 𝐂𝐑𝐘𝐗𝐄𝐍 𝕏 𝙶𝚛𝚘𝚞𝚙 𝚂𝚞𝚖𝚖𝚘𝚗𝚒𝚗𝚐 ✦
┃ 
┃ 🏷️ *Sanctuaire* : ${groupName}
┃ 👥 *Âmes détectées* : ${totalMembers}
┃ 🕯️ *Message d’Invocation* :
┃ ${msg}
╰──────⊰𓆩☠️𓆪⊱──────╯

⚰️ *Victimes marquées* :
`;

    for (const member of participants) {
      if (member?.id) {
        text += `${glyph} @${member.id.split("@")[0]}\n`;
      }
    }

    text += `\n🔮 *Marquage effectué par CRYXEN 𝕏.*`;

    await conn.sendMessage(from, {
      text: text,
      mentions: participants.map(u => u.id)
    }, { quoted: mek });

  } catch (err) {
    console.error("🔥 Erreur invocation tagall:", err);
    reply(`❌ *Une anomalie s’est glissée dans le rituel :* ${err.message || err}`);
  }
});