const config = require('../settings');
const { malvin } = require('../malvin');
const fs = require('fs');

// Vérifie si une valeur est activée
function isEnabled(value) {
    return value && value.toString().toLowerCase() === 'true';
}

// Génère le texte stylisé des paramètres
function generateSettingsList() {
    const settingsList = [
        { name: 'Vue des statuts', key: 'AUTO_STATUS_SEEN', emoji: '👁️' },
        { name: 'Réponse aux statuts', key: 'AUTO_STATUS_REPLY', emoji: '💬' },
        { name: 'Auto-Réponse', key: 'AUTO_REPLY', emoji: '↩️' },
        { name: 'Sticker Auto', key: 'AUTO_STICKER', emoji: '🖼️' },
        { name: 'Réactions perso', key: 'CUSTOM_REACT', emoji: '👍' },
        { name: 'Réaction Auto', key: 'AUTO_REACT', emoji: '💥' },
        { name: 'Suppression des liens', key: 'DELETE_LINKS', emoji: '🔗' },
        { name: 'Anti-Lien', key: 'ANTI_LINK', emoji: '🚫' },
        { name: 'Anti-Insultes', key: 'ANTI_BAD', emoji: '🛑' },
        { name: 'Saisie Auto', key: 'AUTO_TYPING', emoji: '⌨️' },
        { name: 'Enregistrement Auto', key: 'AUTO_RECORDING', emoji: '🎙️' },
        { name: 'Toujours en ligne', key: 'ALWAYS_ONLINE', emoji: '🌐' },
        { name: 'Mode Public', key: 'PUBLIC_MODE', emoji: '🌍' },
        { name: 'Lecture des messages', key: 'READ_MESSAGE', emoji: '📖' },
    ];

    return settingsList.map(s => 
        `┃ 🔹 *${s.emoji} ${s.name}* : ${isEnabled(config[s.key]) ? "✅ Activé" : "❌ Désactivé"}`
    ).join('\n');
}

malvin({
    pattern: 'env',
    alias: ['setting', 'allvar'],
    desc: 'Afficher les paramètres du bot',
    category: 'main',
    react: '⚙️',
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    try {
        const settingsMessage = `
╔═⫷ 𝙲𝚁𝚈𝚇𝙴𝙽 𝕏 • 𝙲𝙾𝙽𝙵𝙸𝙶 ⫸═╗

┃ 📌 *ÉTAT ACTUEL DU BOT*
${generateSettingsList()}

┃ 💀 *Description* :
┃ ${config.DESCRIPTION || 'Aucune description définie'}

╚═⫷ 𝚃𝙷𝙴 𝙲𝙷𝙾𝚂𝙴𝙽 𝙲𝙾𝙳𝙴 ⫸═╝
`.trim();

        const imageUrl = config.IMAGE_URL || 'https://files.catbox.moe/ebqp72.png';

        // Envoi du message
        await conn.sendMessage(from, {
            image: { url: imageUrl },
            caption: settingsMessage
        }, { quoted: mek });

        // Envoi de l'audio (voix démoniaque d'intro par exemple)
        await conn.sendMessage(from, {
            audio: fs.readFileSync('./autos/intro.m4a'),
            mimetype: 'audio/mp4',
            ptt: true
        }, { quoted: mek });

    } catch (e) {
        console.error("❌ Erreur dans la commande env :", e);
        reply("⚠️ Une erreur s’est produite lors de la récupération des paramètres.");
    }
});