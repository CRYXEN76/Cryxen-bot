const { malvin } = require("../malvin");

malvin({
  pattern: "vv",
  alias: ["viewonce", "retrive"],
  react: "☠️",
  desc: "👹 Commande sacrée du Seigneur CRYXEN 𝕏 — Récupère le contenu maudit des messages 'view once'",
  category: "owner",
  filename: __filename
}, async (client, message, match, { from, isCreator, reply }) => {
  try {
    if (!isCreator) {
      return await client.sendMessage(from, {
        text: "🚫 *Commande réservée à l’Empereur CRYXEN 𝕏. Recule, simple mortel.*"
      }, { quoted: message });
    }

    if (!match.quoted) {
      return await client.sendMessage(from, {
        text: "💀 *Réponds à un message 'view once' pour briser son sceau infernal...*"
      }, { quoted: message });
    }

    const buffer = await match.quoted.download();
    const mtype = match.quoted.mtype;
    const options = { quoted: message };

    let messageContent = {};
    switch (mtype) {
      case "imageMessage":
        messageContent = {
          image: buffer,
          caption: "🔥 *L’image interdite dévoilée par la volonté du maître...*",
          mimetype: match.quoted.mimetype || "image/jpeg"
        };
        break;
      case "videoMessage":
        messageContent = {
          video: buffer,
          caption: "🔥 *La vidéo maudite est désormais à ta merci...*",
          mimetype: match.quoted.mimetype || "video/mp4"
        };
        break;
      case "audioMessage":
        messageContent = {
          audio: buffer,
          mimetype: "audio/mp4",
          ptt: match.quoted.ptt || false,
          caption: "🔥 *Même le son secret est capturé par mon pouvoir...*"
        };
        break;
      default:
        return await client.sendMessage(from, {
          text: "💀 *Seules les images, vidéos et audios peuvent succomber à mon emprise.*"
        }, { quoted: message });
    }

    await client.sendMessage(from, messageContent, options);
  } catch (error) {
    console.error("💀 Commande vv erreur fatale:", error);
    await client.sendMessage(from, {
      text: "☠️ *Erreur démoniaque lors de la récupération...*\n" + error.message
    }, { quoted: message });
  }
});