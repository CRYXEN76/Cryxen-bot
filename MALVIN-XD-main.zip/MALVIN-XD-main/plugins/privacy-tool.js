const fs = require("fs");
const path = require('path');
const config = require("../settings");
const { malvin, commands } = require("../malvin");
const axios = require("axios");

malvin({
    pattern: "privacy",
    alias: ["privacymenu"],
    desc: "Menu des paramètres de confidentialité",
    category: "owner",
    react: "🔐",
    filename: __filename
}, 
async (conn, mek, m, { from, reply }) => {
    try {
        let privacyMenu = `╭━━〔 *⚔️ CRYXEN 𝕏 — CONFIDENTIALITÉ ⚔️* 〕━━┈⊷
┃◈╭─────────────·๏
┃◈┃• blocklist — Voir utilisateurs bloqués
┃◈┃• getbio — Voir la bio d’un utilisateur
┃◈┃• setppall — Définir photo profil propriétaire
┃◈┃• setonline — Mettre statut en ligne propriétaire
┃◈┃• setpp — Modifier photo profil bot
┃◈┃• setmyname — Changer nom du bot
┃◈┃• updatebio — Modifier bio du bot
┃◈┃• groupsprivacy — Gérer autorisation ajout groupes
┃◈┃• getprivacy — Voir réglages privés actuels
┃◈┃• getpp — Voir photo profil d’un utilisateur
┃◈┃
┃◈┃*Options pour commandes propriétaires :*
┃◈┃• all — Tout le monde
┃◈┃• contacts — Mes contacts uniquement
┃◈┃• contact_blacklist — Contacts sauf bloqués
┃◈┃• none — Personne
┃◈┃• match_last_seen — Correspondre dernière vue
┃◈└───────────┈⊷
╰──────────────┈⊷
*Note:* La plupart des commandes sont réservées au propriétaire du bot`;

        await conn.sendMessage(
            from,
            {
                image: { url: `https://files.catbox.moe/e463lh` },
                caption: privacyMenu,
            },
            { quoted: mek }
        );

    } catch (e) {
        console.log(e);
        reply(`❌ Erreur : ${e.message}`);
    }
});


malvin({
    pattern: "blocklist",
    desc: "Voir la liste des utilisateurs bloqués.",
    category: "owner",
    react: "📋",
    filename: __filename
},
async (conn, mek, m, { from, isOwner, reply }) => {
    if (!isOwner) return reply("🚫 Tu n'es pas le propriétaire !");

    try {
        const blockedUsers = await conn.fetchBlocklist();

        if (blockedUsers.length === 0) {
            return reply("📋 Ta liste de blocage est vide.");
        }

        const list = blockedUsers
            .map(user => `🚧 UTILISATEUR BLOQUÉ : ${user.split('@')[0]}`)
            .join('\n');

        reply(`📋 Utilisateurs bloqués (${blockedUsers.length}) :\n\n${list}`);
    } catch (err) {
        console.error(err);
        reply(`❌ Échec récupération liste blocage : ${err.message}`);
    }
});


malvin({
    pattern: "getbio",
    desc: "Afficher la bio d’un utilisateur.",
    category: "owner",
    filename: __filename,
}, async (conn, mek, m, { args, reply }) => {
    try {
        const jid = args[0] || mek.key.remoteJid;
        const about = await conn.fetchStatus?.(jid);
        if (!about) return reply("⚠️ Aucune bio trouvée.");
        return reply(`📝 Bio de l'utilisateur :\n\n${about.status}`);
    } catch (error) {
        console.error("Erreur bio:", error);
        reply("⚠️ Aucune bio trouvée.");
    }
});


malvin({
    pattern: "setppall",
    desc: "Modifier la confidentialité de la photo de profil du propriétaire",
    category: "owner",
    react: "🔐",
    filename: __filename
}, 
async (conn, mek, m, { args, isOwner, reply }) => {
    if (!isOwner) return reply("🚫 Tu n'es pas le propriétaire !");
    
    try {
        const value = args[0] || 'all'; 
        const validValues = ['all', 'contacts', 'contact_blacklist', 'none'];  
        
        if (!validValues.includes(value)) {
            return reply("❌ Option invalide. Options valides : 'all', 'contacts', 'contact_blacklist', 'none'.");
        }
        
        await conn.updateProfilePicturePrivacy(value);
        reply(`✅ Confidentialité photo profil propriétaire définie sur : ${value}`);
    } catch (e) {
        return reply(`❌ Une erreur est survenue.\n\nErreur : ${e.message}`);
    }
});


malvin({
    pattern: "setonline",
    desc: "Modifier la confidentialité du statut en ligne",
    category: "owner",
    react: "🔐",
    filename: __filename
}, 
async (conn, mek, m, { args, isOwner, reply }) => {
    if (!isOwner) return reply("🚫 Tu n'es pas le propriétaire !");

    try {
        const value = args[0] || 'all'; 
        const validValues = ['all', 'match_last_seen'];
        
        if (!validValues.includes(value)) {
            return reply("❌ Option invalide. Options valides : 'all', 'match_last_seen'.");
        }

        await conn.updateOnlinePrivacy(value);
        reply(`✅ Confidentialité statut en ligne définie sur : ${value}`);
    } catch (e) {
        return reply(`❌ Une erreur est survenue.\n\nErreur : ${e.message}`);
    }
});


malvin({
    pattern: "setpp",
    desc: "Changer la photo de profil du bot.",
    category: "owner",
    react: "🖼️",
    filename: __filename
},
async (conn, mek, m, { isOwner, quoted, reply }) => {
    if (!isOwner) return reply("🚫 Tu n'es pas le propriétaire !");
    if (!quoted || !quoted.message.imageMessage) return reply("⚠️ Merci de répondre à une image.");
    try {
        const stream = await conn.downloadMediaMessage(quoted.message.imageMessage, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        const mediaPath = path.join(__dirname, `${Date.now()}.jpg`);
        fs.writeFileSync(mediaPath, buffer);

        await conn.updateProfilePicture(conn.user.jid, { url: `file://${mediaPath}` });
        reply("✅ Photo de profil modifiée avec succès !");
    } catch (error) {
        console.error("Erreur modification photo profil :", error);
        reply(`❌ Erreur lors de la modification : ${error.message}`);
    }
});


malvin({
    pattern: "setmyname",
    desc: "Changer le nom affiché du bot.",
    category: "owner",
    react: "⚙️",
    filename: __filename
},
async (conn, mek, m, { isOwner, reply, args }) => {
    if (!isOwner) return reply("🚫 Tu n'es pas le propriétaire !");

    const displayName = args.join(" ");
    if (!displayName) return reply("⚠️ Merci de fournir un nom d'affichage.");

    try {
        await conn.updateProfileName(displayName);
        reply(`✅ Le nom du bot est maintenant : ${displayName}`);
    } catch (err) {
        console.error(err);
        reply("❌ Impossible de changer le nom.");
    }
});


malvin({
    pattern: "updatebio",
    react: "🥏",
    desc: "Changer la bio du bot.",
    category: "owner",
    filename: __filename
},
async (conn, mek, m, { isOwner, reply, args }) => {
    if (!isOwner) return reply('🚫 Tu dois être propriétaire pour utiliser cette commande.');
    const q = args.join(" ");
    if (!q) return reply('❓ Entre la nouvelle bio.');
    if (q.length > 139) return reply('❗ Limite de caractères dépassée.');
    try {
        await conn.updateProfileStatus(q);
        reply("✔️ Nouvelle bio mise à jour avec succès !");
    } catch (e) {
        reply('🚫 Une erreur est survenue !\n\n' + e.message);
    }
});


malvin({
    pattern: "groupsprivacy",
    desc: "Modifier la confidentialité d’ajout au groupe",
    category: "owner",
    react: "🔐",
    filename: __filename
}, 
async (conn, mek, m, { args, isOwner, reply }) => {
    if (!isOwner) return reply("🚫 Tu n'es pas le propriétaire !");

    try {
        const value = args[0] || 'all'; 
        const validValues = ['all', 'contacts', 'contact_blacklist', 'none'];
        
        if (!validValues.includes(value)) {
            return reply("❌ Option invalide. Options valides : 'all', 'contacts', 'contact_blacklist', 'none'.");
        }

        await conn.updateGroupsAddPrivacy(value);
        reply(`✅ Confidentialité ajout groupe définie sur : ${value}`);
    } catch (e) {
        return reply(`❌ Une erreur est survenue.\n\nErreur : ${e.message}`);
    }
});


malvin({
    pattern: "getprivacy",
    desc: "Voir les réglages privés du bot.",
    category: "owner",
    filename: __filename
},
async (conn, mek, m, { isOwner, reply }) => {
    try {
        if (!isOwner) return reply('🚫 Tu dois être propriétaire pour cette commande.');
        const duka = await conn.fetchPrivacySettings?.(true);
        if (!duka) return reply('🚫 Échec récupération des paramètres.');

        let puka = `
╭───「 𝙿𝚁𝙸𝚅𝙰𝙲𝚈  」───◆  
│ ∘ Lecture des confirmations : ${duka.readreceipts}  
│ ∘ Photo de profil : ${duka.profile}  
│ ∘ Statut : ${duka.status}  
│ ∘ En ligne : ${duka.online}  
│ ∘ Dernière vue : ${duka.last}  
│ ∘ Confidentialité groupe : ${duka.groupadd}  
│ ∘ Confidentialité appels : ${duka.calladd}  
╰────────────────────`;
        await conn.sendMessage(m.chat, { text: puka }, { quoted: mek });
    } catch (e) {
        reply('🚫 Une erreur est survenue !\n\n' + e.message);
        console.error(e);
    }
});


malvin({
    pattern: "getpp",
    desc: "Récupérer la photo profil d’un utilisateur tagué ou cité.",
    category: "owner",
    filename: __filename
}, async (conn, mek, m, { quoted, sender, reply }) => {
    try {
        const targetJid = quoted ? quoted.sender : sender;

        if (!targetJid) return reply("⚠️ Merci de répondre à un message pour récupérer la photo.");

        const userPicUrl = await conn.profilePictureUrl(targetJid, "image").catch(() => null);

        if (!userPicUrl) return reply("⚠️ Aucun photo de profil trouvée.");

        await conn.sendMessage(m.chat, {
            image: { url: userPicUrl },
            caption: "🖼️ Photo de profil récupérée avec succès."
        });
    } catch (e) {
        console.error("Erreur récupération photo profil :", e);
        reply("❌ Une erreur est survenue lors de la récupération de la photo.");
    }
});