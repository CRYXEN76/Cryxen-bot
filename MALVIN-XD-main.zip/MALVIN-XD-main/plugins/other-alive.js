const config = require('../settings')
const { malvin } = require('../malvin')

malvin({
    pattern: "live",
    desc: "Check if CRYXEN 𝕏 is alive.",
    category: "main",
    react: "💀",
    filename: __filename
},
async (conn, mek, m, { from, reply, pushname }) => {
    try {
        const message = `
╔═══════════════════════╗
║  ⚔  𝕮𝖗𝖞𝖝𝖊𝖓 ²¹⁰⁹  ⚔
╠═══════════════════════╣
║  👋 Yo, ${pushname} !
║
║  ▸ Version: ${config.version || "1.0.0"}
║  ▸ Créateur: 𝙲𝚁𝚈𝚇𝙴𝙽²¹⁰⁹
║
║  ──────── Règles ────────
║  • Pas de spam
║  • Pas d'appels
║  • Respect strict
║
║  ➥ Tape .menu pour débuter
╚═══════════════════════╝
        `.trim();

        await conn.sendMessage(from, {
            image: { url: "https://files.catbox.moe/7hqhsw.jpg" },
            caption: message,
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: mek });

    } catch (e) {
        console.error(e);
        reply(`❌ Erreur : ${e.message || e}`);
    }
});
