const { malvin } = require('../malvin');
const config = require("../settings");

// Systme anti-mots sales de l'enfer
malvin({
  on: "body"
}, async (conn, m, store, {
  from,
  body,
  isGroup,
  isAdmins,
  isBotAdmins,
  reply,
  sender
}) => {
  try {
    const badWords = ["wtf", "mia", "xxx", "fuck", "sex", "huththa", "pakaya", "ponnaya", "hutto"];

    if (!isGroup || isAdmins || !isBotAdmins) {
      return; // Ignore hors groupe, admins, ou si bot pas admin
    }

    const messageText = body.toLowerCase();
    const containsBadWord = badWords.some(word => messageText.includes(word));

    if (containsBadWord && config.ANTI_BAD_WORD === "true") {
      // Suppression du message maudit
      await conn.sendMessage(from, { delete: m.key }, { quoted: m });

      // Avertissement sombre et direct
      await conn.sendMessage(from, { text: "   interdit les mots impurs ici. Retire a ou subis le chaos." }, { quoted: m });
    }
  } catch (error) {
    console.error(error);
    reply(" Une erreur a frapp lors de la vrification du message.");
  }
});