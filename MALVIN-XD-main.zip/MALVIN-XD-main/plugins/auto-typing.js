const fs = require('fs');
const path = require('path');
const config = require('../settings');
const { malvin, commands } = require('../malvin');

// Composition infernale : le bot affiche qu'il tape un message pour impressionner les mortels
malvin({
  on: "body"
}, async (conn, mek, m, { from }) => {
  try {
    if (config.AUTO_TYPING === 'true') {
      // Envoie le status "composing" pour faire croire au bot qu'il réfléchit intensément
      await conn.sendPresenceUpdate('composing', from);
    }
  } catch (error) {
    console.error("🔥 Auto-typing error:", error);
  }
});
