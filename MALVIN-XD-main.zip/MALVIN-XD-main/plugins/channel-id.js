const { malvin } = require("../malvin");

malvin({
  pattern: "newsletter",
  alias: ["cjid", "id"],
  react: "📡",
  desc: "Obtiens les informations d’un canal WhatsApp depuis son lien",
  category: "whatsapp",
  filename: __filename
}, async (conn, mek, m, { from, args, q, reply }) => {
  try {
    if (!q)
      return reply(`❎ *Fournis un lien de canal WhatsApp valide.*\n\n📌 *Exemple:*\n.newsletter https://whatsapp.com/channel/xxxxxxxxxx`);

    const match = q.match(/whatsapp\.com\/channel\/([\w-]+)/);
    if (!match)
      return reply(`⚠️ *Lien invalide !*\n\nAssure-toi qu’il ressemble à :\nhttps://whatsapp.com/channel/xxxxxxxxx`);

    const inviteId = match[1];
    let metadata;

    try {
      metadata = await conn.newsletterMetadata("invite", inviteId);
    } catch {
      return reply("🚫 *Impossible d’obtenir les infos du canal.*\nVérifie le lien et réessaie.");
    }

    if (!metadata?.id)
      return reply("❌ *Canal introuvable ou inaccessible.*");

    const infoText = `
╔═━━━◥◣📡 𝙄𝙉𝙁𝙊 𝘿𝙐 𝘾𝘼𝙉𝘼𝙇 ◢◤━━━═╗
║
║ 🔖 𝙄𝘿             : *${metadata.id}*
║ 🗂️ 𝙉𝙊𝙈            : *${metadata.name}*
║ 👥 𝘼𝘽𝙊𝙉𝙉𝙀́𝙎    : *${metadata.subscribers?.toLocaleString() || "N/A"}*
║ 🗓️ 𝘾𝙍𝙀́𝘼𝙏𝙄𝙊𝙉    : *${metadata.creation_time ? new Date(metadata.creation_time * 1000).toLocaleString("fr-FR") : "Inconnu"}*
║
╚═━━━◥◣ 𝘾𝙍𝙔𝙓𝙀𝙉 𝕏 ◢◤━━━═╝
`.trim();

    if (metadata.preview) {
      await conn.sendMessage(from, {
        image: { url: `https://pps.whatsapp.net${metadata.preview}` },
        caption: infoText
      }, { quoted: m });
    } else {
      reply(infoText);
    }

  } catch (err) {
    console.error("❌ Newsletter Error:", err);
    reply("⚠️ *Une erreur inattendue s’est produite en récupérant les infos du canal.*");
  }
});