const { malvin } = require('../malvin');

function normalizeJid(jid) {
  if (!jid) return null;
  return jid.includes('@') ? jid.split('@')[0] + '@s.whatsapp.net' : jid + '@s.whatsapp.net';
}

malvin({
  pattern: "remove",
  alias: ["kick", "k"],
  desc: "💀 Exile un membre du groupe, réservé au seigneur sombre.",
  category: "admin",
  react: "🔥",
  filename: __filename
}, async (conn, mek, m, { from, q, isGroup, isBotAdmins, reply, quoted, sender }) => {
  if (!isGroup) return reply("⛔ *Ce rituel s'accomplit uniquement dans les cercles sombres (groupes).*");

  if (!isBotAdmins) return reply("⚠️ *Je dois détenir les pouvoirs d'administrateur pour cette damnation.*");

  const botOwner = normalizeJid(conn.user.id.split(":")[0]);
  const senderJid = normalizeJid(sender);

  if (senderJid !== botOwner) {
    return reply("❌ *Seul le maître des ténèbres peut lancer cette sentence.*");
  }

  let number;

  if (quoted) {
    number = quoted.sender.split("@")[0];
  } else if (q) {
    number = q.replace(/[@\s]/g, '');
  } else {
    return reply("⚠️ *Fournis-moi l'âme à bannir en répondant ou en mentionnant son numéro.*");
  }

  const jidToRemove = normalizeJid(number);

  if (jidToRemove === botOwner) {
    return reply("😈 *Je ne peux pas bannir mon propre seigneur... l’ordre serait brisé.*");
  }

  try {
    await conn.groupParticipantsUpdate(from, [jidToRemove], "remove");
    reply(`🔥 *L'âme maudite @${number} a été exilée des terres sacrées !*`, { mentions: [jidToRemove] });
  } catch (error) {
    console.error("Erreur commande remove:", error);
    reply("💀 *La damnation a échoué... Réessaye, ou prépare-toi à affronter les conséquences.*");
  }
});