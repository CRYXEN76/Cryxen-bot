const { malvin } = require('../malvin');
const { getBuffer, fetchJson } = require('../lib/functions');

malvin({
    pattern: "person",
    react: "👤",
    alias: ["userinfo", "profile"],
    desc: "Get complete user profile information",
    category: "owner",
    use: '.person [@tag or reply]',
    filename: __filename
},
async (conn, mek, m, { from, sender, isGroup, reply, quoted, participants }) => {
    try {
        // 1. DÉTERMINER L'UTILISATEUR CIBLE
        let userJid = quoted?.sender 
            || mek.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] 
            || sender;

        // 2. VÉRIFIER SI L'UTILISATEUR EXISTE SUR WhatsApp
        const [user] = await conn.onWhatsApp(userJid).catch(() => []);
        if (!user?.exists) return reply("❌ Utilisateur introuvable sur WhatsApp");

        // 3. RÉCUPÉRER LA PHOTO DE PROFIL
        let ppUrl;
        try {
            ppUrl = await conn.profilePictureUrl(userJid, 'image');
        } catch {
            ppUrl = 'https://i.ibb.co/KhYC4FY/1221bc0bdd2354b42b293317ff2adbcf-icon.png'; // image fallback
        }

        // 4. RÉCUPÉRER LE NOM (plusieurs sources)
        let userName = userJid.split('@')[0];
        try {
            if (isGroup) {
                const member = participants.find(p => p.id === userJid);
                if (member?.notify) userName = member.notify;
            }

            if (userName === userJid.split('@')[0] && conn.contactDB) {
                const contact = await conn.contactDB.get(userJid).catch(() => null);
                if (contact?.name) userName = contact.name;
            }

            if (userName === userJid.split('@')[0]) {
                const presence = await conn.presenceSubscribe(userJid).catch(() => null);
                if (presence?.pushname) userName = presence.pushname;
            }
        } catch (e) {
            console.log("Erreur récupération nom :", e);
        }

        // 5. RÉCUPÉRER LE BIO / ABOUT
        let bio = {};
        try {
            const statusData = await conn.fetchStatus(userJid).catch(() => null);
            if (statusData?.status) {
                bio = {
                    text: statusData.status,
                    type: "Personnel",
                    updated: statusData.setAt ? new Date(statusData.setAt * 1000) : null
                };
            } else {
                const businessProfile = await conn.getBusinessProfile(userJid).catch(() => null);
                if (businessProfile?.description) {
                    bio = {
                        text: businessProfile.description,
                        type: "Business",
                        updated: null
                    };
                }
            }
        } catch (e) {
            console.log("Erreur récupération bio :", e);
        }

        // 6. RÔLE EN GROUPE (si applicable)
        let groupRole = "";
        if (isGroup) {
            const participant = participants.find(p => p.id === userJid);
            groupRole = participant?.admin ? "👑 Admin" : "👥 Membre";
        }

        // 7. FORMATAGE DU TEXTE DE SORTIE
        const formattedBio = bio.text ? 
            `${bio.text}\n└─ 📌 Bio ${bio.type}${bio.updated ? ` | 🕒 ${bio.updated.toLocaleString()}` : ''}` : 
            "Aucune bio disponible";

        const userInfo = `
*GC MEMBER INFORMATION 🧊*

📛 *Nom:* ${userName}
🔢 *Numéro:* ${userJid.replace(/@.+/, '')}
📌 *Type de compte:* ${user.isBusiness ? "💼 Business" : user.isEnterprise ? "🏢 Entreprise" : "👤 Personnel"}

*📝 À propos :*
${formattedBio}

*⚙️ Infos compte :*
✅ Enregistré : ${user.isUser ? "Oui" : "Non"}
🛡️ Vérifié : ${user.verifiedName ? "✅ Vérifié" : "❌ Non vérifié"}
${isGroup ? `👥 *Rôle en groupe:* ${groupRole}` : ''}
`.trim();

        // 8. ENVOYER LE RÉSULTAT
        await conn.sendMessage(from, {
            image: { url: ppUrl },
            caption: userInfo,
            mentions: [userJid]
        }, { quoted: mek });

    } catch (e) {
        console.error("Erreur commande person :", e);
        reply(`❌ Erreur : ${e.message || "Échec lors de la récupération du profil"}`);
    }
});