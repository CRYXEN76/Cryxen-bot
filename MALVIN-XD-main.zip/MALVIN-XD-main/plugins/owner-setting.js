const config = require('../settings');
const { malvin } = require('../malvin');

malvin({
    pattern: "live",
    desc: "Vérifier si le bot est en ligne.",
    category: "main",
    react: "👹",
    filename: __filename
}, async (conn, mek, m, { from, reply, pushname }) => {
    try {
        const texte = `
╔════════════════════════════╗
║     ⚡ 𝕮𝖗𝖞𝖝𝖊𝖓 𝕏 𝕭𝖔𝖙 ⚡
╠════════════════════════════╣
║ 👹 Salut, ${pushname} !
║
║ 🔥 Bot: 𝕮𝖗𝖞𝖝𝖊𝖓 𝕏 - Le démon du code
║ 👑 Propriétaire: 𝙲𝚁𝚈𝚇𝙴𝙽²¹⁰⁹
║ ⚙️ Version: ${config.version}
║ 💀 Script: Plugins malveillants
║
║ ⛓️ Système automatisé redoutable
║ 🛡️ Protège les groupes comme un guerrier
║
║ 📜 Règles impératives :
║ 1️⃣ Pas de spam, ou tu goûtes à la purge.
║ 2️⃣ Pas d’appels, ou tu subis la sentence.
║ 3️⃣ Respect total ou enfer assuré.
║
║ ⚠️ Tape .menu pour découvrir tes armes.
╚════════════════════════════╝
`;
        await conn.sendMessage(from, {
            image: { url: config.MENU_IMAGE_URL || "https://files.catbox.moe/awpotj.jpeg" },
            caption: texte,
            contextInfo: {
                mentionedJid: [m.sender]
            }
        }, { quoted: mek });
    } catch (e) {
        console.error(e);
        reply("❌ Une erreur est survenue lors de l'exécution.");
    }
});