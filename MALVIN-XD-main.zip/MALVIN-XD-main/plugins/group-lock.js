const config = require('../settings');
const { malvin, commands } = require('../malvin');
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson } = require('../lib/functions');

malvin({
    pattern: "lockgc",
    alias: ["lock"],
    react: "🔒",
    desc: "Verrouille le groupe (Empêche les nouveaux membres d'entrer).",
    category: "group",
    filename: __filename
},           
async (conn, mek, m, { from, isGroup, isAdmins, isBotAdmins, reply }) => {
    try {
        if (!isGroup) 
            return reply("⛔ *Cette puissance n'est accessible que dans les cercles secrets (groupes).*");

        if (!isAdmins) 
            return reply("❌ *Seuls les maîtres du groupe peuvent exécuter ce rituel.*");

        if (!isBotAdmins) 
            return reply("⚠️ *Je dois être admin pour sceller cette porte (verrouiller le groupe).*");

        await conn.groupSettingUpdate(from, "locked");

        return reply("🔒 *Le cercle est scellé ! Aucun intrus ne franchira la porte.*");
    } catch (e) {
        console.error("Erreur lors du verrouillage du groupe:", e);
        return reply("💀 *Échec du rituel de verrouillage. Réessaye plus tard.*");
    }
});
