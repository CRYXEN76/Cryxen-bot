const config = require('../settings');
const { malvin } = require('../malvin');
const { fetchJson } = require('../lib/functions');

malvin({
  pattern: "ginfo",
  react: "🥏",
  alias: ["groupinfo"],
  desc: "Affiche les informations du groupe.",
  category: "groupe",
  use: ".ginfo",
  filename: __filename
},
async (conn, mek, m, { from, isGroup, isAdmins, isBotAdmins, participants, reply }) => {
  try {
    if (!isGroup) return reply("❌ Cette malédiction est réservée aux groupes.");

    if (!isAdmins && !config.DEV.includes(m.sender.split("@")[0]))
      return reply("❌ Seuls les admin peuvent invoquer cette puissance.");

    if (!isBotAdmins) return reply("❌ Je dois être admin pour révéler ces secrets.");

    const fallbackPp = 'https://i.ibb.co/KhYC4FY/1221bc0bdd2354b42b293317ff2adbcf-icon.png';

    let ppUrl;
    try {
      ppUrl = await conn.profilePictureUrl(from, 'image');
    } catch {
      ppUrl = fallbackPp;
    }

    const metadata = await conn.groupMetadata(from);
    const groupAdmins = participants.filter(p => p.admin);
    const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n');
    const owner = metadata.owner || "Inconnu";

    const gdata = `
╔════════════════════╗
║  🔥 𝔾𝕣𝕠𝕦𝕡𝕖 𝕀𝕟𝕗𝕠 𝕓𝕪 𝕔𝕣𝕪𝕩𝕖𝕟 🔥
╚════════════════════╝

╔════════════════════╗
║ 🔰 Nom : ${metadata.subject}
║ 🆔 ID : ${metadata.id}
║ 👑 Créateur : ${owner.split('@')[0]}
║ 👥 Membres : ${metadata.size}
║ 📜 Description : ${metadata.desc?.toString() || 'Aucune description'}
╚════════════════════╝

╔════════════════════╗
║ ⚔️ Admins :
║ ${listAdmin}
╚════════════════════╝
    `;

    await conn.sendMessage(from, { image: { url: ppUrl }, caption: gdata, contextInfo: { mentionedJid: groupAdmins.map(a => a.id) } }, { quoted: mek });

  } catch (e) {
    console.error(e);
    reply("❌ Une erreur sombre est survenue. Réessaie plus tard.");
  }
});