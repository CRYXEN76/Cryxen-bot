const { malvin } = require('../malvin');
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

malvin({
    pattern: "removemembers",
    alias: ["kickall", "endgc", "endgroup"],
    desc: "Purge tous les membres non-admins du groupe.",
    react: "",
    category: "group",
    filename: __filename,
},
async (conn, mek, m, { from, groupMetadata, groupAdmins, isBotAdmins, senderNumber, reply, isGroup }) => {
    try {
        if (!isGroup) return reply(" *Commande exclusive aux groupes.*");

        const botOwner = conn.user.id.split(":")[0];
        if (senderNumber !== botOwner)
            return reply(" *Seul le Ma�tre du Chaos (owner) peut lancer cette purge.*");

        if (!isBotAdmins) return reply(" *Je dois �tre administrateur pour ex�cuter cette extermination.*");

        const all = groupMetadata.participants;
        const victims = all.filter(p => !groupAdmins.includes(p.id));

        if (!victims.length) return reply(" *Tous sont d�j� dignes (admins). Aucun � sacrifier.*");

        reply(` *Lancement de la purge...* (${victims.length} �mes cibl�es)`);

        for (let target of victims) {
            await conn.groupParticipantsUpdate(from, [target.id], "remove");
            await sleep(2000);
        }

        reply(" *Ex�cution termin�e. Seuls les dignes ont surv�cu.*");
    } catch (e) {
        console.error(e);
        reply(" *Erreur lors de l'ex�cution du sacrifice :*\n" + e.message);
    }
});

// deuxi�me bloque 

const { malvin } = require('../malvin');
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

malvin({
    pattern: "removeadmins",
    alias: ["kickadmins", "kickall3", "deladmins"],
    desc: "�limine tous les admins sauf le bot et son ma�tre.",
    react: "",
    category: "group",
    filename: __filename,
},
async (conn, mek, m, { from, isGroup, senderNumber, groupMetadata, groupAdmins, isBotAdmins, reply }) => {
    try {
        if (!isGroup) return reply(" *Commande r�serv�e aux groupes.*");

        const botOwner = conn.user.id.split(":")[0];
        if (senderNumber !== botOwner)
            return reply(" *Seul le Seigneur Supr�me peut renverser les chefs.*");

        if (!isBotAdmins) return reply(" *Je dois �tre admin pour cette op�ration.*");

        const all = groupMetadata.participants;
        const targets = all.filter(p =>
            groupAdmins.includes(p.id) &&
            p.id !== conn.user.id &&
            p.id !== `${botOwner}@s.whatsapp.net`
        );

        if (!targets.length)
            return reply(" *Aucun admin � renverser. Tous sont soit sacr�s, soit d�j� exclus.*");

        reply(` *R�bellion activ�e. Chute des chefs en cours... (${targets.length})*`);

        for (let target of targets) {
            await conn.groupParticipantsUpdate(from, [target.id], "remove");
            await sleep(2000);
        }

        reply(" *R�bellion achev�e. Tous les chefs ont �t� bannis.*");
    } catch (e) {
        console.error(e);
        reply(" *Erreur durant la r�bellion :*\n" + e.message);
    }
});


//troisi�me bloque 


const { malvin } = require('../malvin');
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

malvin({
    pattern: "removeall2",
    alias: ["kickall2", "endgc2", "endgroup2"],
    desc: "An�antit tous les membres sauf le bot et son propri�taire.",
    react: "",
    category: "group",
    filename: __filename,
},
async (conn, mek, m, { from, isGroup, senderNumber, groupMetadata, isBotAdmins, reply }) => {
    try {
        if (!isGroup) return reply(" *Uniquement dans un sanctuaire (groupe).*");

        const botOwner = conn.user.id.split(":")[0];
        if (senderNumber !== botOwner)
            return reply(" *Seul le Seigneur CRYXEN  peut d�clencher l'Apocalypse.*");

        if (!isBotAdmins) return reply(" *Je dois �tre admin pour d�clencher l��radication.*");

        const all = groupMetadata.participants;
        const victims = all.filter(p =>
            p.id !== conn.user.id &&
            p.id !== `${botOwner}@s.whatsapp.net`
        );

        if (!victims.length)
            return reply(" *Aucun �tre � exterminer. Le vide est d�j� l�.*");

        reply(` *APOCALYPSE ACTIV�E ! (${victims.length} �mes cibl�es)*`);

        for (let target of victims) {
            await conn.groupParticipantsUpdate(from, [target.id], "remove");
            await sleep(2000);
        }

        reply(" *L�univers est purifi�. Il ne reste que le chaos et la volont� de CRYXEN .*");
    } catch (e) {
        console.error(e);
        reply(" *Erreur durant l'�radication :*\n" + e.message);
    }
});
