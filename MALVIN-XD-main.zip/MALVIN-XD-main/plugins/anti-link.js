const { malvin } = require('../malvin');
const config = require("../settings");

// Gardien infernal Anti-Link CRYXEN 𝕏
malvin({
  on: "body"
}, async (conn, m, store, {
  from,
  body,
  sender,
  isGroup,
  isAdmins,
  isBotAdmins,
  reply
}) => {
  try {
    if (!global.warnings) global.warnings = {};

    // N'agis que si bot admin, dans groupe, et auteur n'est pas admin
    if (!isGroup || isAdmins || !isBotAdmins) return;

    // Patterns démoniaques de liens interdits
    const linkPatterns = [
      /https?:\/\/(?:chat\.whatsapp\.com|wa\.me)\/\S+/gi,
      /https?:\/\/(?:api\.whatsapp\.com|wa\.me)\/\S+/gi,
      /wa\.me\/\S+/gi,
      /https?:\/\/(?:t\.me|telegram\.me)\/\S+/gi,
      /https?:\/\/(?:www\.)?\.com\/\S+/gi,
      /https?:\/\/(?:www\.)?twitter\.com\/\S+/gi,
      /https?:\/\/(?:www\.)?linkedin\.com\/\S+/gi,
      /https?:\/\/(?:whatsapp\.com|channel\.me)\/\S+/gi,
      /https?:\/\/(?:www\.)?reddit\.com\/\S+/gi,
      /https?:\/\/(?:www\.)?discord\.com\/\S+/gi,
      /https?:\/\/(?:www\.)?twitch\.tv\/\S+/gi,
      /https?:\/\/(?:www\.)?vimeo\.com\/\S+/gi,
      /https?:\/\/(?:www\.)?dailymotion\.com\/\S+/gi,
      /https?:\/\/(?:www\.)?medium\.com\/\S+/gi
    ];

    if (!config.ANTI_LINK || config.ANTI_LINK !== 'true') return;

    const containsLink = linkPatterns.some(pattern => pattern.test(body));

    if (containsLink) {
      // Suppression du message maudit
      try {
        await conn.sendMessage(from, { delete: m.key });
      } catch {}

      // Comptage des avertissements
      global.warnings[sender] = (global.warnings[sender] || 0) + 1;
      const warns = global.warnings[sender];

      if (warns < 4) {
        await conn.sendMessage(from, {
          text:
`☠️ 𝙲𝚁𝚈𝚇𝙴𝙽 𝟷𝟶 —═╬✞╬═— GARDIEN DES PORTES —═╬✞╬═—
╭─━═╬⚠️╬═━─╮
│ 𝙰𝚅𝙴𝚁𝚃𝙸𝚂𝚂𝙴𝙼𝙴𝙽𝚃
│
├▢ 𝙰𝚞𝚝𝚎𝚞𝚛 : @${sender.split('@')[0]}
├▢ 𝙰𝚟𝚎𝚛𝚝𝚒𝚜𝚜𝚎𝚖𝚎𝚗𝚝𝚜 : ${warns} / 3
├▢ 𝚁𝚊𝚒𝚜𝚘𝚗 : Envoi de liens interdits
╰─━═╬☠️╬═━─╯`,
          mentions: [sender]
        });
      } else {
        await conn.sendMessage(from, {
          text: `💀 @${sender.split('@')[0]} A ÉTÉ EXPULSÉ - LIMITE D’AVERTISSEMENTS DÉPASSÉE !`,
          mentions: [sender]
        });
        await conn.groupParticipantsUpdate(from, [sender], "remove");
        delete global.warnings[sender];
      }
    }
  } catch (error) {
    console.error("Erreur anti-link:", error);
    reply("❌ Une erreur est survenue lors de la surveillance des liens.");
  }
});