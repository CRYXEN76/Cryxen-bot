const config = require('../settings')
const { malvin, commands } = require('../malvin')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')

malvin({
    pattern: "unmute",
    alias: ["groupunmute"],
    react: "🔊",
    desc: "🗣️ Libère la parole : le groupe peut enfin hurler à nouveau.",
    category: "group",
    filename: __filename
},           
async (conn, mek, m, { from, isGroup, senderNumber, isAdmins, isBotAdmins, reply }) => {
    try {
        if (!isGroup) return reply("⛔ *Cette invocation ne peut s'exécuter que dans un sanctuaire de groupe.*");
        if (!isAdmins) return reply("❌ *Seuls les Seigneurs du groupe (admins) peuvent briser ce silence.*");
        if (!isBotAdmins) return reply("⚠️ *Je dois être Admin pour libérer le flot des messages.*");

        await conn.groupSettingUpdate(from, "not_announcement");
        reply("🗣️ *Le silence est brisé ! Tous peuvent désormais crier dans ce groupe.*");
    } catch (e) {
        console.error("Erreur lors de la libération du groupe :", e);
        reply("❌ *Un mur invisible empêche la parole. Essaye encore...*\n\n" + e.message);
    }
});