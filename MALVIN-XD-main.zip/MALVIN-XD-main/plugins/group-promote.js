const { malvin } = require('../malvin');

malvin({
    pattern: "promote",
    alias: ["p", "makeadmin"],
    desc: "Élève un membre au rang d'Admin Infernal",
    category: "admin",
    react: "⏫",
    filename: __filename
},
async (conn, mek, m, {
    from, quoted, q, isGroup, isAdmins, isBotAdmins, botNumber, reply
}) => {

    if (!isGroup)
        return reply("🚫 *Royaume réservé aux groupes.*");

    if (!isAdmins)
        return reply("🔒 *Tu n’as pas les clés du pouvoir. Seuls les admin peuvent invoquer cette élévation.*");

    if (!isBotAdmins)
        return reply("🪬 *Donne-moi les ailes de l’autorité. Je ne suis pas encore Admin.*");

    let number;
    if (quoted) {
        number = quoted.sender.split("@")[0];
    } else if (q && q.includes("@")) {
        number = q.replace(/[@\s]/g, '');
    } else {
        return reply("📜 *Désigne une cible. Réponds à son message ou fournis son numéro.*");
    }

    if (number === botNumber)
        return reply("🤖 *Je ne m’élève pas moi-même. Le chaos n’a pas besoin de hiérarchie.*");

    const jid = number + "@s.whatsapp.net";

    try {
        await conn.groupParticipantsUpdate(from, [jid], "promote");
        reply(`👑 *Élévation confirmée !*\n\n@${number} rejoint le cercle des damnés au pouvoir.`, { mentions: [jid] });
    } catch (err) {
        console.error("❌ Promote command error:", err);
        reply("💥 *L'invocation a échoué. Le pacte n’a pas été scellé.*");
    }
});