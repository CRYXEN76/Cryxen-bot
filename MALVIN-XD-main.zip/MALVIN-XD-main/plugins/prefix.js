const { malvin } = require('../malvin');
const config = require('../settings');
const { setPrefix } = require('../lib/prefix');

malvin({
  pattern: "setprefix",
  alias: ["prefix"],
  react: "🔧",
  desc: "Modifier le préfixe de commande du bot.",
  category: "paramètres",
  filename: __filename,
}, async (conn, mek, m, { args, isCreator, reply }) => {
  if (!isCreator) 
    return reply("⛔ *Seul le maître des ténèbres peut changer le préfixe !*");

  const newPrefix = args[0];
  if (!newPrefix) 
    return reply("❌ *Fournis un nouveau préfixe, par exemple :* `.setprefix !`");

  setPrefix(newPrefix); // mise à jour immédiate, pas besoin de redémarrer

  return reply(`✅ *Préfixe diabolique changé en* : *${newPrefix}* — le chaos est lancé sans délai.`);
});