const fs = require("fs");
const path = require("path");
const { malvin } = require("../malvin");

const OWNER_PATH = path.join(__dirname, "../lib/sudo.json");

// S'assure que le fichier sudo.json existe
const ensureOwnerFile = () => {
  if (!fs.existsSync(OWNER_PATH)) {
    fs.writeFileSync(OWNER_PATH, JSON.stringify([]));
  }
};
ensureOwnerFile();

const CRYXEN_BANNER = "💀 𝙲𝚁𝚈𝚇𝙴𝙽 𝕏 — SUDO CONTROL 💀";

malvin({
  pattern: "setsudo",
  alias: ["addsudo", "addowner", "sudo"],
  desc: "Ajoute un propriétaire temporaire au cercle des ténèbres.",
  category: "owner",
  react: "🎭",
  filename: __filename
}, async (conn, mek, m, { from, args, isCreator, reply }) => {
  if (!isCreator) return reply("⛔ Seul le maître absolu peut invoquer cette puissance !");
  
  let target = m.mentionedJid?.[0] || m.quoted?.sender || (args[0]?.replace(/[^0-9]/g, '') + "@s.whatsapp.net");
  if (!target) return reply("⚠️ Donne un numéro ou mentionne une âme à asservir.");

  let owners = JSON.parse(fs.readFileSync(OWNER_PATH, "utf-8"));
  if (owners.includes(target)) return reply("⚠️ Cette âme est déjà sous ton contrôle.");

  owners.push(target);
  owners = [...new Set(owners)];
  fs.writeFileSync(OWNER_PATH, JSON.stringify(owners, null, 2));

  await conn.sendMessage(from, {
    image: { url: "https://files.catbox.moe/qumhu4.jpg" },
    caption: `${CRYXEN_BANNER}\n\n✅ L'âme *${target.replace("@s.whatsapp.net", "")}* a été ajoutée aux propriétaires temporaires.\n\n🕷️ Le pouvoir grandit...`,
    contextInfo: { forwardingScore: 0, isForwarded: false }
  }, { quoted: mek });
});

malvin({
  pattern: "delsudo",
  alias: ["delowner", "deletesudo"],
  desc: "Exclut un propriétaire temporaire de la légion.",
  category: "owner",
  react: "🫩",
  filename: __filename
}, async (conn, mek, m, { from, args, isCreator, reply }) => {
  if (!isCreator) return reply("⛔ Seul le maître absolu peut invoquer cette puissance !");
  
  let target = m.mentionedJid?.[0] || m.quoted?.sender || (args[0]?.replace(/[^0-9]/g, '') + "@s.whatsapp.net");
  if (!target) return reply("⚠️ Donne un numéro ou mentionne une âme à bannir.");

  let owners = JSON.parse(fs.readFileSync(OWNER_PATH, "utf-8"));
  if (!owners.includes(target)) return reply("⚠️ Cette âme n'est pas dans la liste des propriétaires.");

  const updated = owners.filter(x => x !== target);
  fs.writeFileSync(OWNER_PATH, JSON.stringify(updated, null, 2));

  await conn.sendMessage(from, {
    image: { url: "https://files.catbox.moe/qumhu4.jpg" },
    caption: `${CRYXEN_BANNER}\n\n✅ L'âme *${target.replace("@s.whatsapp.net", "")}* a été expulsée des propriétaires temporaires.\n\n🔥 Le cercle s'affaiblit...`,
    contextInfo: { forwardingScore: 0, isForwarded: false }
  }, { quoted: mek });
});

malvin({
  pattern: "listsudo",
  alias: ["listowner"],
  desc: "Affiche la liste des âmes possédant temporairement le pouvoir.",
  category: "owner",
  react: "📋",
  filename: __filename
}, async (conn, mek, m, { from, isCreator, reply }) => {
  if (!isCreator) return reply("⛔ Seul le maître absolu peut invoquer cette puissance !");

  let owners = JSON.parse(fs.readFileSync(OWNER_PATH, "utf-8"));
  owners = [...new Set(owners)];

  if (owners.length === 0) return reply("⚠️ Aucun propriétaire temporaire n'a été invoqué.");

  let listMessage = `💀 𝙲𝚁𝚈𝚇𝙴𝙽 𝕏 — PROPRIÉTAIRES TEMPORAIRES 💀\n\n`;
  owners.forEach((owner, i) => {
    listMessage += `⛓️ ${i + 1}. ${owner.replace("@s.whatsapp.net", "")}\n`;
  });

  await conn.sendMessage(from, {
    image: { url: "https://files.catbox.moe/iqkzzn.jpg" },
    caption: listMessage,
    contextInfo: { forwardingScore: 0, isForwarded: false }
  }, { quoted: mek });
});