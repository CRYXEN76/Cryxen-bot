const config = require('../settings');
const { malvin } = require('../malvin');
const { getGroupAdmins } = require('../lib/functions');

malvin({
    pattern: "tagadmins",
    alias: ["gc_tagadmins"],
    desc: "Mentionne tous les admins du groupe avec puissance.",
    category: "group",
    react: "👑",
    use: ".tagadmins [message]",
    filename: __filename
}, 
async (conn, mek, m, {
    from, isGroup, participants, reply, body, command
}) => {
    try {
        if (!isGroup) return reply("❌ Cette commande ne fonctionne qu'en groupe.");

        const groupInfo = await conn.groupMetadata(from).catch(() => null);
        if (!groupInfo) return reply("❌ Impossible de récupérer les infos du groupe.");

        const groupName = groupInfo.subject || "Groupe sans nom";
        const admins = await getGroupAdmins(participants);

        if (!admins || admins.length === 0) {
            return reply("❌ Aucun admin trouvé dans ce groupe.");
        }

        // Emojis sombres et puissants style CRYXEN
        const emojis = ['💀', '🔥', '⚔️', '🛡️', '☠️', '🔱', '🌑', '🕷️', '⚡', '🩸'];
        const chosenEmoji = emojis[Math.floor(Math.random() * emojis.length)];

        // Message personnalisé ou défaut
        const messageText = body
            .replace(new RegExp(`^${config.PREFIX}${command}\\s*`, 'i'), '')
            .trim() || "⚠️ Attention, admins sombres à l'appel !";

        let teks = `🔥 *⚔️ CRYXEN 𝕏 - ALERT ADMIN ⚔️*\n`;
        teks += `🕸️ *Groupe* : ${groupName}\n`;
        teks += `👥 *Nombre d'Admins* : ${admins.length}\n`;
        teks += `💬 *Message* : ${messageText}\n\n`;
        teks += `╔═══⊷ *Liste des Admins* ⊷═══\n`;

        for (let admin of admins) {
            teks += `${chosenEmoji} @${admin.split("@")[0]}\n`;
        }

        teks += `╚═════✦ 𝙲𝚁𝚈𝚇𝙴𝙽 𝕏 ✦═════`;

        await conn.sendMessage(from, {
            text: teks,
            mentions: admins,
            contextInfo: {
                forwardingScore: 0,
                isForwarded: false
            }
        }, { quoted: mek });

    } catch (e) {
        console.error("Erreur tagadmins:", e);
        reply(`❌ Une erreur est survenue :\n${e.message || e}`);
    }
});