const { getInactiveUsers } = require('../lib/activityTracker');
const config = require('../settings');
const { malvin } = require('../malvin');

malvin({
  pattern: "taginactive",
  desc: "Tague les membres inactifs depuis plus de 7 jours.",
  category: "groupe",
  react: "⏳",
  filename: __filename,
},
async (conn, mek, m, { from, isGroup, participants, reply }) => {
  if (!isGroup) return reply("❌ Cette malédiction ne s’abat que sur les groupes.");

  const inactiveIds = getInactiveUsers(7);
  const inactive = participants.filter(p => inactiveIds.includes(p.id));

  if (!inactive.length) return reply("✅ Aucun fantôme détecté. Le groupe est vivant.");

  let teks = `⏳ *MORTS-VIVANTS DETECTÉS*\nMembres inactifs depuis 7 jours ou plus :\n\n`;
  for (const u of inactive) teks += `⚠️ @${u.id.split("@")[0]} - Réveille-toi ou péris !\n`;

  await conn.sendMessage(from, { text: teks, mentions: inactive.map(p => p.id) }, { quoted: mek });
});