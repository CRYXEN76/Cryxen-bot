const { malvin } = require('../malvin');
const { getAnti, setAnti } = require('../data/antidel');

malvin({
    pattern: "antidelete",
    alias: ['antidel', 'del'],
    desc: "Active ou désactive le bouclier anti-suppression infernal",
    category: "settings",
    filename: __filename
},
async (conn, mek, m, { from, reply, text, isCreator }) => {
    if (!isCreator) return reply('❌ *Accès refusé.* Seul 𝙲𝚁𝚈𝚇𝙴𝙽²¹⁰⁹ peut manier ce pouvoir.');

    try {
        const currentStatus = await getAnti();

        if (!text || text.toLowerCase() === 'status') {
            return reply(`🔥 *Statut Anti-Suppression:* ${currentStatus ? '✅ ACTIVÉ' : '❌ DÉSACTIVÉ'}\n\nUtilisation:\n• .antidelete on - Activer\n• .antidelete off - Désactiver`);
        }

        const action = text.toLowerCase().trim();

        if (action === 'on') {
            await setAnti(true);
            return reply('☠️ *Bouclier Anti-Suppression activé. Aucun message ne disparaîtra sous ma garde.*');
        } else if (action === 'off') {
            await setAnti(false);
            return reply('💀 *Bouclier Anti-Suppression désactivé. Le chaos peut s’étendre.*');
        } else {
            return reply('❌ Commande invalide. Usage:\n• .antidelete on\n• .antidelete off\n• .antidelete status');
        }
    } catch (e) {
        console.error("Erreur dans la commande antidelete :", e);
        return reply('⚠️ Une erreur a frappé lors du traitement de ta requête démoniaque.');
    }
});