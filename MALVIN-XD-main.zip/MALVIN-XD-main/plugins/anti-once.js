const { malvin } = require("../malvin");

malvin({
  pattern: "vv2",
  alias: ["wah", "ohh", "oho", "🙂", "nice", "ok"],
  desc: "👹 Commande exclusive du Seigneur CRYXEN 𝕏 — Récupère les secrets des messages 'view once'",
  category: "owner",
  filename: __filename
}, async (client, message, match, { from, isCreator, reply }) => {
  try {
    if (!isCreator) return; // ⚠️ Seul le Maître a ce pouvoir.

    if (!match.quoted) {
      return reply("💀 *Tu dois répondre à un message 'view once' pour en briser le sortilège...*");
    }

    const buffer = await match.quoted.download();
    const mtype = match.quoted.mtype;
    const options = { quoted: message };

    let messageContent = {};
    switch (mtype) {
      case "imageMessage":
        messageContent = {
          image: buffer,
          caption: "🔥 *Voici ce qui devait rester invisible...*",
          mimetype: match.quoted.mimetype || "image/jpeg"
        };
        break;
      case "videoMessage":
        messageContent = {
          video: buffer,
          caption: "🔥 *Le voile est levé sur cette vidéo interdite...*",
          mimetype: match.quoted.mimetype || "video/mp4"
        };
        break;
      case "audioMessage":
        messageContent = {
          audio: buffer,
          mimetype: "audio/mp4",
          ptt: match.quoted.ptt || false,
          caption: "🔥 *Même le son ne t’échappera pas...*"
        };
        break;
      default:
        return reply("💀 *Seulement images, vidéos et audios peuvent succomber à ma puissance.*");
    }

    await client.sendMessage(message.sender, messageContent, options);
  } catch (error) {
    console.error("💀 Commande vv2 erreur fatale:", error);
    reply("☠️ *Erreur démoniaque lors de la récupération...* \n" + error.message);
  }
});