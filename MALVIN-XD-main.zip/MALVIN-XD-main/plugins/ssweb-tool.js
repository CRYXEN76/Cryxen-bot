// code by ⿻ ⌜ CRYXEN 𝕏 ⌟⿻⃮͛

const axios = require("axios");
const { malvin } = require('../malvin');

malvin({
  pattern: "ss",
  alias: ["ssweb", "screenshot"],
  react: "💫",
  desc: "Capture une capture d'écran d'un site web.",
  category: "other",
  use: ".ss <url>",
  filename: __filename
}, 
async (conn, mek, m, { from, q, reply }) => {
  if (!q) {
    return reply("🌐 Donne un lien valide pour la capture.\n\n📌 Exemple : `.ss https://exemple.com`");
  }

  if (!/^https?:\/\//i.test(q)) {
    return reply("❗ Le lien doit commencer par `http://` ou `https://`");
  }

  try {
    const apiUrl = `https://api.davidcyriltech.my.id/ssweb?url=${encodeURIComponent(q)}`;
    const res = await axios.get(apiUrl);

    if (!res.data || !res.data.screenshotUrl) {
      return reply("⚠️ Impossible de capturer la page. Essaie un autre lien.");
    }

    const imageMessage = {
      image: { url: res.data.screenshotUrl },
      caption: `🖼️ *Capture d'écran générée*\n\n🔗 *URL:* ${q}\n\n💀 © CRYXEN 𝕏 — Puissance et Ombre`,
      contextInfo: {
        forwardingScore: 0,
        isForwarded: false
      }
    };

    await conn.sendMessage(from, imageMessage, { quoted: m });

  } catch (err) {
    console.error("Erreur capture écran:", err);
    reply("❌ Échec de la capture. Réessaie plus tard.");
  }
});