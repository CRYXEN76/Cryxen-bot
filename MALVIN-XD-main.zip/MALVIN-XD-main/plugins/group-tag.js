const { malvin } = require('../malvin');

malvin({
  pattern: "hidetag",
  alias: ["tag", "h"],
  react: "🕯️",
  desc: "Invoque les âmes du groupe en silence...",
  category: "group",
  use: '.hidetag ⚠️ Réunion d’ombre',
  filename: __filename
},
async (conn, mek, m, {
  from, q, isGroup, isCreator, isAdmins,
  participants, reply
}) => {
  try {
    if (!isGroup)
      return reply("🚫 *Ce rituel est réservé aux groupes.*");

    if (!isAdmins && !isCreator)
      return reply("🔒 *Seuls les maîtres du cercle (admins) peuvent déclencher l'invocation.*");

    const mentionAll = { mentions: participants.map(p => p.id) };

    // Rien envoyé, rien cité
    if (!q && !m.quoted)
      return reply("🕳️ *Il faut invoquer un message ou répondre à une âme pour les marquer tous.*");

    // Cas où le message est une réponse
    if (m.quoted) {
      const type = m.quoted.mtype || "";

      if (type === "extendedTextMessage") {
        return conn.sendMessage(from, {
          text: m.quoted.text || "🕯️ Chant maudit...",
          ...mentionAll
        }, { quoted: mek });
      }

      // Cas des médias : image, vidéo, audio, doc, sticker
      try {
        const buffer = await m.quoted.download?.();
        if (!buffer)
          return reply("📛 *Impossible de voler le message du néant.*");

        let content;
        switch (type) {
          case "imageMessage":
            content = { image: buffer, caption: m.quoted.text || "📷 Image invoquée", ...mentionAll };
            break;
          case "videoMessage":
            content = {
              video: buffer,
              caption: m.quoted.text || "🎥 Vision spectrale",
              gifPlayback: m.quoted.message?.videoMessage?.gifPlayback || false,
              ...mentionAll
            };
            break;
          case "audioMessage":
            content = {
              audio: buffer,
              mimetype: "audio/mp4",
              ptt: m.quoted.message?.audioMessage?.ptt || false,
              ...mentionAll
            };
            break;
          case "stickerMessage":
            content = { sticker: buffer, ...mentionAll };
            break;
          case "documentMessage":
            content = {
              document: buffer,
              mimetype: m.quoted.message?.documentMessage?.mimetype || "application/octet-stream",
              fileName: m.quoted.message?.documentMessage?.fileName || "archive_maudite",
              caption: m.quoted.text || "",
              ...mentionAll
            };
            break;
        }

        if (content)
          return conn.sendMessage(from, content, { quoted: mek });

      } catch (e) {
        console.error("⛔ Erreur média:", e);
        return reply("❌ *Échec du rituel média. Envoi en mode texte brut.*");
      }

      // Fallback : autre type de message
      return conn.sendMessage(from, {
        text: m.quoted.text || "🕯️ Sombre murmure",
        ...mentionAll
      }, { quoted: mek });
    }

    // Si message direct
    if (q) {
      const isUrl = (txt) =>
        /https?:\/\/(www\.)?[\w\-@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([\w\-@:%_\+.~#?&//=]*)/.test(txt);

      await conn.sendMessage(from, {
        text: q,
        ...mentionAll
      }, { quoted: mek });
    }

  } catch (e) {
    console.error("❌ Hidetag Error:", e);
    reply(`🔥 *Une anomalie est survenue...*\n\n${e.message}`);
  }
});