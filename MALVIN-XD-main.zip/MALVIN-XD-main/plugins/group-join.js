const config = require('../settings');
const { malvin } = require('../malvin');
const { isUrl } = require('../lib/functions');

malvin({
    pattern: "join",
    react: "📬",
    alias: ["joinme", "f_join"],
    desc: "Rejoins un groupe via un lien d'invitation.",
    category: "groupe",
    use: ".join <lien du groupe>",
    filename: __filename
}, async (conn, mek, m, { from, quoted, q, isCreator, reply }) => {
    try {
        if (!isCreator) return reply("❌ Cette commande est réservée au maître des ténèbres.");

        if (!q && !quoted) return reply("🖤 *Donne-moi un lien valide de groupe, sombre guerrier.*");

        let groupLink;

        if (quoted && quoted.type === 'conversation' && isUrl(quoted.text)) {
            groupLink = quoted.text.split('https://chat.whatsapp.com/')[1];
        } else if (q && isUrl(q)) {
            groupLink = q.split('https://chat.whatsapp.com/')[1];
        }

        if (!groupLink) return reply("❌ *Lien de groupe invalide, réessaye.* 🖇️");

        await conn.groupAcceptInvite(groupLink);

        const successMsg = `
╔════════════════════╗
║  ✅ INVITATION ACCEPTÉE ✅
╠════════════════════╣
║ Le bot a rejoint le groupe,
║ prêt à semer le chaos.
╚════════════════════╝
        `.trim();

        await conn.sendMessage(from, { text: successMsg }, { quoted: mek });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
        reply(`❌ Une erreur obscure est survenue :\n\n${e}`);
    }
});