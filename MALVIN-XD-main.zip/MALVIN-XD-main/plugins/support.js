/*
Projet       : CRYXEN 𝕏
Créateur     : 𝙲𝚁𝚈𝚇𝙴𝙽²¹⁰⁹
Repo GitHub  : https://github.com/CRYXEN76
Contact      : wa.me/2250545477175
*/

const config = require('../settings');
const { malvin } = require('../malvin');
const { runtime } = require('../lib/functions');

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

malvin({
    pattern: "support",
    alias: ["follow", "links"],
    desc: "Affiche les liens de support et de suivi.",
    category: "main",
    react: "📡",
    filename: __filename
}, 
async (conn, mek, m, {
    from, reply, pushname
}) => {
    try {
        const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const uptimeFormatted = runtime(process.uptime());

        const message = `
╭─『 *𝙲𝚁𝚈𝚇𝙴𝙽 𝕏 - SUPPORT & LIENS* 』─
│ 👤 *Propriétaire* : 𝙲𝚁𝚈𝚇𝙴𝙽²¹⁰⁹
│ ⚙️ *Mode*        : ${config.MODE}
│ ⏱️ *Uptime*      : ${uptimeFormatted}
│ 💠 *Préfixe*     : ${config.PREFIX}
│ 🔖 *Version*     : ${config.version}
│ 🕰️ *Heure*       : ${currentTime}
╰─────────────────────

📢 *Soutiens & Suivis CRYXEN 𝕏* ${readMore}

🔔 *Chaîne WhatsApp Officielle*
🔗 https://chat.whatsapp.com/CRYXEN

🎬 *Chaîne YouTube*
🔗 https://youtube.com/@foden225-i2j

👑 *Contact Propriétaire*
🔗 wa.me/2250545477175?text=Salut%20CRYXEN,%20j%27ai%20besoin%20d%27aide!

> 💀 Propulsé par *𝙲𝚁𝚈𝚇𝙴𝙽 𝕏* 💀
        `.trim();

        await conn.sendMessage(from, {
            image: { url: 'https://files.catbox.moe/iqkzzn.jpg' }, // Image CRYXEN personnalisée
            caption: message,
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 0,
                isForwarded: false
            }
        }, { quoted: mek });

    } catch (e) {
        console.error("Erreur commande support:", e);
        reply(`⚠️ Une erreur est survenue :\n${e.message}`);
    }
});