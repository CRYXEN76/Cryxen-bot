const config = require('../settings');
const { malvin, commands } = require('../malvin');
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson } = require('../lib/functions');

malvin({
    pattern: "mute",
    alias: ["groupmute"],
    react: "🔇",
    desc: "Muter le groupe (Seuls les admins peuvent parler).",
    category: "group",
    filename: __filename
},           
async (conn, mek, m, { from, isGroup, senderNumber, isAdmins, isBotAdmins, reply }) => {
    try {
        if (!isGroup) 
            return reply("⛔ *Cette incantation ne fonctionne que dans les groupes maudits.*");

        if (!isAdmins) 
            return reply("❌ *Seuls les seigneurs du groupe peuvent lancer ce sort de silence.*");

        if (!isBotAdmins) 
            return reply("⚠️ *Je dois être admin pour imposer le silence absolu.*");

        await conn.groupSettingUpdate(from, "announcement");

        return reply("🔇 *Le silence divin est tombé. Seuls les maîtres peuvent briser la quiétude.*");
    } catch (e) {
        console.error("Erreur lors du muting du groupe:", e);
        return reply("💀 *Le sortilège a échoué. Réessaye quand les astres seront alignés.*");
    }
});