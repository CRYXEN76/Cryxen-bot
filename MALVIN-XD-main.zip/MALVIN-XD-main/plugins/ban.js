const fs = require("fs");
const path = require("path");
const { malvin } = require("../malvin");

const BAN_FILE = "./lib/ban.json";

function readBanList() {
    if (!fs.existsSync(BAN_FILE)) fs.writeFileSync(BAN_FILE, "[]");
    return JSON.parse(fs.readFileSync(BAN_FILE, "utf-8"));
}

function writeBanList(list) {
    fs.writeFileSync(BAN_FILE, JSON.stringify([...new Set(list)], null, 2));
}

malvin({
    pattern: "ban",
    alias: ["blockuser", "addban"],
    desc: "⛓ Bannir un intrus du royaume CRYXEN 𝕏",
    category: "owner",
    react: "⛔",
    filename: __filename
}, async (conn, mek, m, { from, args, isCreator, reply }) => {
    if (!isCreator) return reply("_❗ Seul le maître CRYXEN 𝕏 peut manier cette commande !_");

    let target = m.mentionedJid?.[0] 
        || (m.quoted?.sender ?? null)
        || (args[0]?.replace(/[^0-9]/g, '') + "@s.whatsapp.net");

    if (!target) return reply("❌ Indique le numéro ou tague un ennemi à bannir.");

    let banned = readBanList();

    if (banned.includes(target)) return reply("❌ Cet être est déjà banni dans l'ombre.");

    banned.push(target);
    writeBanList(banned);

    await conn.sendMessage(from, {
        image: { url: "https://files.catbox.moe/awpotj.jpeg" },
        caption: `⛔ L'usurpateur @${target.replace("@s.whatsapp.net","")} est banni du domaine CRYXEN 𝕏.`
    }, { quoted: mek });
});

malvin({
    pattern: "unban",
    alias: ["removeban"],
    desc: "🔓 Libérer un prisonnier de la purge",
    category: "owner",
    react: "✅",
    filename: __filename
}, async (conn, mek, m, { from, args, isCreator, reply }) => {
    if (!isCreator) return reply("_❗ Seul le maître CRYXEN 𝕏 peut manier cette commande !_");

    let target = m.mentionedJid?.[0] 
        || (m.quoted?.sender ?? null)
        || (args[0]?.replace(/[^0-9]/g, '') + "@s.whatsapp.net");

    if (!target) return reply("❌ Indique le numéro ou tague celui à libérer.");

    let banned = readBanList();

    if (!banned.includes(target)) return reply("❌ Cet être n'est pas enfermé dans nos geôles.");

    banned = banned.filter(u => u !== target);
    writeBanList(banned);

    await conn.sendMessage(from, {
        image: { url: "https://files.catbox.moe/awpotj.jpeg" },
        caption: `✅ La sentence est levée, @${target.replace("@s.whatsapp.net","")} est libre... pour l'instant.`
    }, { quoted: mek });
});

malvin({
    pattern: "listban",
    alias: ["banlist", "bannedusers"],
    desc: "📜 Liste des âmes bannies par CRYXEN 𝕏",
    category: "owner",
    react: "📋",
    filename: __filename
}, async (conn, mek, m, { from, isCreator, reply }) => {
    if (!isCreator) return reply("_❗ Seul le maître CRYXEN 𝕏 peut manier cette commande !_");

    let banned = readBanList();

    if (banned.length === 0) return reply("✅ Aucun être n’est banni dans ce royaume.");

    let msg = "`⛔ Liste des bannis :`\n\n";
    banned.forEach((id, i) => {
        msg += `${i + 1}. @${id.replace("@s.whatsapp.net", "")}\n`;
    });

    await conn.sendMessage(from, {
        image: { url: "https://files.catbox.moe/awpotj.jpeg" },
        caption: msg,
        mentions: banned
    }, { quoted: mek });
});