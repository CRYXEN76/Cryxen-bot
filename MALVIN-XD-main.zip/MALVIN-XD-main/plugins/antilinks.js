const { malvin } = require('../malvin');
const config = require("../settings");

// Listes de mots interdits et liens maudits
const badWords = [
  "wtf", "mia", "xxx", "fuck", "sex", "huththa", "pakaya", "ponnaya", "hutto"
];

const linkPatterns = [
  /https?:\/\/(?:chat\.whatsapp\.com|wa\.me)\/\S+/gi,
  /https?:\/\/(?:t\.me|telegram\.me)\/\S+/gi,
  /https?:\/\/(?:www\.)?(youtube|facebook|instagram|twitter|tiktok|linkedin|snapchat|pinterest|reddit|discord|twitch|vimeo|dailymotion|medium)\.com\/\S+/gi,
  /https?:\/\/fb\.me\/\S+/gi,
  /https?:\/\/youtu\.be\/\S+/gi,
  /wa\.me\/\S+/gi,
  /https?:\/\/ngl\/\S+/gi
];

malvin({
  on: "body"
}, async (conn, m, store, { from, body, sender, isGroup, isAdmins, isBotAdmins, reply }) => {
  try {
    if (!isGroup || isAdmins || !isBotAdmins || sender === conn.user?.id) return;

    const text = body.toLowerCase();
    const hasBadWord = config.ANTI_BAD_WORD === "true" && badWords.some(word => text.includes(word));
    const hasLink = config.ANTI_LINK === "true" && linkPatterns.some(pattern => pattern.test(body));

    if (hasBadWord) {
      // Suppression du message toxique
      await conn.sendMessage(from, { delete: m.key });
      // Avertissement dmoniaque
      await conn.sendMessage(from, {
        text: ` *CRYXEN  ne tolre pas les blasphmes.*\n @${sender.split('@')[0]}, tes paroles souillent ce lieu.`,
        mentions: [sender]
      }, { quoted: m });
      return;
    }

    if (hasLink) {
      // Suppression du lien maudit
      await conn.sendMessage(from, { delete: m.key });
      // Expulsion expditive
      await conn.sendMessage(from, {
        text: ` *CRYXEN  protge son sanctuaire.*\n Les liens sont bannis ici.\n\n @${sender.split('@')[0]} a t expuls sans piti.`,
        mentions: [sender]
      }, { quoted: m });

      await conn.groupParticipantsUpdate(from, [sender], "remove");
    }
  } catch (error) {
    console.error(" Erreur antilinks:", error);
    reply(" Une sombre erreur a interrompu la purification du groupe.");
  }
});