const config = require('../settings')
const { malvin, commands } = require('../malvin')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson } = require('../lib/functions')

malvin({
    pattern: "unlockgc",
    alias: ["unlock"],
    react: "🔓",
    desc: "🔓 Ouvre les portes du groupe à de nouvelles âmes.",
    category: "group",
    filename: __filename
},
async (conn, mek, m, { from, isGroup, isAdmins, isBotAdmins, reply }) => {
    try {
        if (!isGroup) return reply("⛔ *Cette incantation ne peut être récitée que dans un groupe sacré.*");
        if (!isAdmins) return reply("❌ *Seuls les Maîtres (admins) peuvent déverrouiller le portail.*");
        if (!isBotAdmins) return reply("⚠️ *Je dois être Admin pour manipuler les chaînes du groupe.*");

        await conn.groupSettingUpdate(from, "unlocked");
        reply("🔓 *Le portail est ouvert ! De nouvelles entités peuvent maintenant entrer...*");
    } catch (e) {
        console.error("Erreur lors du déverrouillage du groupe :", e);
        reply("❌ *Une force obscure a empêché l’ouverture du portail.*\n\n" + e.message);
    }
});
