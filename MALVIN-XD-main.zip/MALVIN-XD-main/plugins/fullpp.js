const { malvin } = require('../malvin');
const Jimp = require("jimp");
const { S_WHATSAPP_NET } = require('@whiskeysockets/baileys');

malvin({
  pattern: "pp",
  desc: "Changer la photo de profil du bot.",
  category: "owner",
  filename: __filename
},
async (conn, mek, m, {
  quoted, reply
}) => {

  try {
    if (!quoted || !/image/.test(quoted.mimetype)) {
      return reply("📸 *Réponds à une image pour la définir comme photo de profil.*");
    }

    // Télécharger l'image
    const media = await quoted.download();

    // Lire et redimensionner l'image
    const jimp = await Jimp.read(media);
    const cropped = jimp.crop(0, 0, jimp.getWidth(), jimp.getHeight());
    const img = await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG);

    // Appliquer comme photo de profil
    await conn.query({
      tag: 'iq',
      attrs: {
        to: S_WHATSAPP_NET,
        type: 'set',
        xmlns: 'w:profile:picture',
      },
      content: [{
        tag: 'picture',
        attrs: { type: 'image' },
        content: img,
      }],
    });

    return reply("✅ *𝙲𝚁𝚈𝚇𝙴𝙽 𝕏 vient de renaître avec une nouvelle face...* 😈");
  } catch (err) {
    console.error("❌ Erreur dans .pp :", err);
    return reply("🚫 *Impossible de changer la photo de profil.*\nVérifie le format de l’image ou réessaie.");
  }

});