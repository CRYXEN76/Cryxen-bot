const config = require('../settings')
const { malvin } = require('../malvin')

malvin({
    pattern: "updategname",
    alias: ["upgname", "gname"],
    react: "📝",
    desc: "Change le nom du groupe avec autorité.",
    category: "groupe",
    filename: __filename
},           
async (conn, mek, m, { from, isGroup, isAdmins, isBotAdmins, q, reply }) => {
    try {
        if (!isGroup) return reply("❌ Cette invocation n’est possible qu’en groupe.");
        if (!isAdmins) return reply("❌ Seuls les seigneurs (admins) peuvent changer le nom.");
        if (!isBotAdmins) return reply("❌ Je dois être admin pour imposer un nouveau nom.");
        if (!q) return reply("❌ Tu dois fournir un nouveau nom, ô maître.");

        await conn.groupUpdateSubject(from, q);
        reply(`✅ Le nom du groupe est désormais : *${q}* — Que la puissance soit avec nous !`);
    } catch (e) {
        console.error("❌ Erreur lors de la mise à jour du nom :", e);
        reply("❌ Échec de la mise à jour. Le chaos règne toujours...");
    }
});
