const { malvin, commands } = require('../malvin');
const config = require('../settings');
const prefix = config.PREFIX;

malvin({
    pattern: "invite",
    alias: ["glink", "grouplink"],
    desc: "Obtiens le lien d'invitation du groupe.",
    category: "group",
    filename: __filename,
}, async (conn, mek, m, { from, isGroup, sender, reply }) => {
    try {
        if (!isGroup) 
            return reply("⛔ *Cette invocation n'existe que dans les cercles maudits (groupes).*");

        const botNumber = conn.user.id.split(":")[0] + '@s.whatsapp.net';

        // Récupérer les métadonnées du groupe
        const metadata = await conn.groupMetadata(from);
        const groupAdmins = metadata.participants.filter(p => p.admin);
        const isBotAdmins = groupAdmins.some(admin => admin.id === botNumber);
        const isSenderAdmin = groupAdmins.some(admin => admin.id === sender);

        if (!isBotAdmins)
            return reply("❌ *Je ne suis pas admin ici. Donne-moi le pouvoir d'ombre (admin)*.");

        if (!isSenderAdmin)
            return reply("❌ *Seuls les maîtres de l'ombre (admins) peuvent invoquer ce secret.*");

        // Obtenir le code d'invitation
        const inviteCode = await conn.groupInviteCode(from);
        if (!inviteCode)
            return reply("⚠️ *L'invocation a échoué... aucun lien d'invitation disponible.*");

        const inviteLink = `https://chat.whatsapp.com/${inviteCode}`;

        return reply(`🔗 *Lien d'invitation du groupe :*\n${inviteLink}\n\n> 𝕮𝖗𝖞𝖝𝖊𝖓 𝕏 — le maître des ombres`);
    } catch (error) {
        console.error("Erreur dans la commande invite:", error);
        reply(`💀 *Erreur fatale :* ${error.message || "Erreur inconnue"}`);
    }
});