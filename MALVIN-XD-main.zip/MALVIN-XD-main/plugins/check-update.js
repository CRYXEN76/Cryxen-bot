const axios = require('axios');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { malvin, commands } = require('../malvin');
const { runtime } = require('../lib/functions');

malvin({
  pattern: 'version',
  alias: ['changelog', 'cupdate', 'checkupdate'],
  react: '🚀',
  desc: 'Affiche la version du bot, infos système, et statut de mise à jour.',
  category: 'owner',
  filename: __filename
}, async (conn, mek, m, { from, pushname, reply }) => {
  try {
    const versionPath = path.join(__dirname, '../data/version.json');
    let localVersion = 'Inconnue';
    let changelog = 'Aucun changelog local.';
    if (fs.existsSync(versionPath)) {
      const data = JSON.parse(fs.readFileSync(versionPath));
      localVersion = data.version;
      changelog = data.changelog || changelog;
    }

    const repoRawURL = 'https://raw.githubusercontent.com/CRYXEN76/CRYXEN-X/main/data/version.json';
    let latestVersion = 'Indisponible';
    let latestChangelog = 'Non récupéré.';
    try {
      const { data } = await axios.get(repoRawURL);
      latestVersion = data.version || latestVersion;
      latestChangelog = data.changelog || latestChangelog;
    } catch (err) {
      console.warn('⚠️ Impossible de récupérer les infos de version à distance.');
    }

    const pluginCount = fs.readdirSync(path.join(__dirname, '../plugins')).filter(f => f.endsWith('.js')).length;
    const commandCount = commands.length;
    const uptime = runtime(process.uptime());
    const ram = process.memoryUsage().heapUsed / 1024 / 1024;
    const totalRam = os.totalmem() / 1024 / 1024;
    const hostname = os.hostname();
    const lastUpdated = fs.statSync(versionPath).mtime.toLocaleString("fr-FR");

    const updateStatus = localVersion !== latestVersion
      ? `🔁 *Mise à jour disponible !*\n📌 Actuelle : *${localVersion}*\n🆕 Dernière : *${latestVersion}*\n\nUtilise *.update* pour mettre à jour.`
      : `✅ *CRYXEN 𝕏 est à jour. Aucun bug n'échappe à sa vigilance.*`;

    const caption = `
╔═━━━━✦❘༻༺❘✦━━━━═╗
     🩸 𝘾𝙍𝙔𝙓𝙀𝙉 𝕏 - 𝙎𝙏𝘼𝙏𝙐𝙎
╚═━━━━✦❘༻༺❘✦━━━━═╝

👤 𝙐𝙩𝙞𝙡𝙞𝙨𝙖𝙩𝙚𝙪𝙧 : *${pushname}*
💀 𝙃𝙤𝙨𝙩𝙣𝙖𝙢𝙚 : *${hostname}*
⏳ 𝙐𝙥𝙩𝙞𝙢𝙚 : *${uptime}*

╔═════ ⌬ 𝙎𝙔𝙎𝙏𝙀̀𝙈𝙀 ⌬ ═════╗
║ ⚡ RAM        : *${ram.toFixed(19)}GB / ${totalRam.toFixed(512)}GB*
║ 🔌 Plugins    : *${pluginCount}*
║ 🧩 Commandes  : *${commandCount}*
╚════════════════════════╝

╔═════ ⌬ 𝙑𝙀𝙍𝙎𝙄𝙊𝙉𝙎 ⌬ ═════╗
║ 📦 Locale     : *${localVersion}*
║ ☁️ Distant    : *${latestVersion}*
╚════════════════════════╝

📆 Dernière mise à jour : ${lastUpdated}
📝 *Changelog :* ${latestChangelog}

${updateStatus}

🔗 *GitHub :* https://github.com/CRYXEN76/CRYXEN-X
🔥 *Le fléau numérique est en marche...*
`.trim();

    await conn.sendMessage(from, {
      image: { url: 'https://files.catbox.moe/01f9y1.jpg' },
      caption
    }, { quoted: mek });

  } catch (error) {
    console.error('❌ Erreur version:', error);
    reply('⚠️ Une erreur s’est produite lors du check de version.');
  }
});