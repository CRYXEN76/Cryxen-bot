const { malvin } = require("../malvin");
const axios = require("axios");

malvin({
  pattern: "rw",
  alias: ["randomwall", "wallpaper"],
  react: "🌌",
  desc: "Télécharge un fond d'écran aléatoire selon mot-clé.",
  category: "fun",
  use: ".rw <mot-clé>",
  filename: __filename
}, async (conn, m, store, { from, args, reply }) => {
  try {
    const query = args.join(" ") || "random";
    const apiUrl = `https://pikabotzapi.vercel.app/random/randomwall/?apikey=anya-md&query=${encodeURIComponent(query)}`;

    const { data } = await axios.get(apiUrl);

    if (data.status && data.imgUrl) {
      const caption = `🌌 *Fond d'écran aléatoire :* ${query}\n\n💀 © CRYXEN 𝕏 — Force et Ombre`;
      await conn.sendMessage(from, { 
        image: { url: data.imgUrl }, 
        caption,
        contextInfo: {
          forwardingScore: 0,
          isForwarded: false
        }
      }, { quoted: m });
    } else {
      reply(`❌ Aucun fond d'écran trouvé pour *"${query}"*.`);
    }
  } catch (error) {
    console.error("Erreur fond d'écran :", error);
    reply("❌ Une erreur est survenue lors de la récupération du fond d'écran. Réessaie plus tard.");
  }
});