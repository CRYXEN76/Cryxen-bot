// CRYXEN X
// Ne supprimez pas les crédits de ce fichier

const { malvin } = require("../malvin");

// Configuration sécurité
const SAFETY = {
  MAX_JIDS: 20,          // Nombre max de groupes à forwarder
  BASE_DELAY: 2000,      // Délai de base entre envois (2s)
  EXTRA_DELAY: 4000,     // Délai plus long tous les 10 envois (4s)
};

malvin({
  pattern: "forward",
  alias: ["fwd"],
  desc: "Transfert en masse de média vers plusieurs groupes",
  category: "owner",
  filename: __filename
}, async (client, message, match, { isOwner }) => {
  try {
    if (!isOwner) return await message.reply("*📛 Commande réservée au propriétaire*");
    if (!message.quoted) return await message.reply("*🍁 Merci de répondre à un message à transférer*");

    // Récupération des JIDs (groupes) à partir de l'argument
    let jidInput = "";
    if (typeof match === "string") jidInput = match.trim();
    else if (Array.isArray(match)) jidInput = match.join(" ").trim();
    else if (match && typeof match === "object") jidInput = match.text || "";

    // Sépare par espaces ou virgules, filtre les vides
    const rawJids = jidInput.split(/[\s,]+/).filter(jid => jid.trim().length > 0);

    // Validation des JIDs (doivent être numériques, suffixe @g.us ajouté)
    const validJids = rawJids
      .map(jid => {
        const cleanJid = jid.replace(/@g\.us$/i, "");
        return /^\d+$/.test(cleanJid) ? `${cleanJid}@g.us` : null;
      })
      .filter(jid => jid !== null)
      .slice(0, SAFETY.MAX_JIDS);

    if (validJids.length === 0) {
      return await message.reply(
        "❌ Aucun JID de groupe valide trouvé.\nExemples valides:\n" +
        ".fwd 120363411055156472@g.us,120363333939099948@g.us\n" +
        ".fwd 120363411055156472 120363333939099948"
      );
    }

    // Préparation du contenu à transférer
    let messageContent = {};
    const mtype = message.quoted.mtype;

    if (["imageMessage", "videoMessage", "audioMessage", "stickerMessage", "documentMessage"].includes(mtype)) {
      const buffer = await message.quoted.download();

      switch (mtype) {
        case "imageMessage":
          messageContent = {
            image: buffer,
            caption: message.quoted.text || '',
            mimetype: message.quoted.mimetype || "image/jpeg"
          };
          break;
        case "videoMessage":
          messageContent = {
            video: buffer,
            caption: message.quoted.text || '',
            mimetype: message.quoted.mimetype || "video/mp4"
          };
          break;
        case "audioMessage":
          messageContent = {
            audio: buffer,
            mimetype: message.quoted.mimetype || "audio/mp4",
            ptt: message.quoted.ptt || false
          };
          break;
        case "stickerMessage":
          messageContent = {
            sticker: buffer,
            mimetype: message.quoted.mimetype || "image/webp"
          };
          break;
        case "documentMessage":
          messageContent = {
            document: buffer,
            mimetype: message.quoted.mimetype || "application/octet-stream",
            fileName: message.quoted.fileName || "document"
          };
          break;
      }
    } else if (["extendedTextMessage", "conversation"].includes(mtype)) {
      messageContent = { text: message.quoted.text };
    } else {
      // Essayer de transférer directement sinon erreur
      try {
        messageContent = message.quoted;
      } catch {
        return await message.reply("❌ Type de message non supporté pour transfert");
      }
    }

    // Envoi avec progression et gestion des erreurs
    let successCount = 0;
    const failedJids = [];

    for (const [index, jid] of validJids.entries()) {
      try {
        await client.sendMessage(jid, messageContent);

        successCount++;
        if ((index + 1) % 10 === 0) {
          await message.reply(`🔄 Transféré à ${index + 1}/${validJids.length} groupes...`);
        }

        const delay = (index + 1) % 10 === 0 ? SAFETY.EXTRA_DELAY : SAFETY.BASE_DELAY;
        await new Promise(r => setTimeout(r, delay));

      } catch {
        failedJids.push(jid.replace("@g.us", ""));
        await new Promise(r => setTimeout(r, SAFETY.BASE_DELAY));
      }
    }

    // Rapport final
    let report = `✅ *Transfert terminé*\n\n` +
                 `📤 Succès : ${successCount}/${validJids.length}\n` +
                 `📦 Type contenu : ${mtype.replace('Message', '') || 'texte'}\n`;

    if (failedJids.length) {
      report += `\n❌ Échecs (${failedJids.length}): ${failedJids.slice(0,5).join(", ")}`;
      if (failedJids.length > 5) report += ` +${failedJids.length - 5} autres`;
    }

    if (rawJids.length > SAFETY.MAX_JIDS) {
      report += `\n⚠️ Limité aux ${SAFETY.MAX_JIDS} premiers groupes.`;
    }

    await message.reply(report);

  } catch (error) {
    console.error("Erreur Forward :", error);
    await message.reply(
      `💢 Erreur : ${error.message.substring(0, 100)}\n\n` +
      `Vérifie :\n` +
      `1. Le format des JIDs\n` +
      `2. Le type de média supporté\n` +
      `3. Les permissions du bot`
    );
  }
});