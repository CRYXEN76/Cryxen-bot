const { malvin } = require("../malvin");
const { sleep } = require("../lib/functions");

malvin({
    pattern: "restart",
    desc: "Redémarre le bot CRYXEN 𝕏 avec puissance.",
    category: "owner",
    react: "🔥",
    filename: __filename
},
async (conn, mek, m, { reply, isOwner }) => {
    try {
        if (!isOwner) return reply("⛔️ Seul le seigneur CRYXEN 𝕏 peut lancer cette commande.");

        await reply("♨️ CRYXEN 𝕏 s'efface... Mais renaît des ténèbres dans 1,5s.");
        await sleep(1500);

        const { exec } = require("child_process");
        exec("pm2 restart all");
    } catch (e) {
        console.error(e);
        reply(`💀 Échec critique du redémarrage : ${e.message || e}`);
    }
});