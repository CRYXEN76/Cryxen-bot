const { sleep } = require('../lib/functions');
const { malvin } = require('../malvin');

malvin({
    pattern: "leave",
    alias: ["left", "leftgc", "leavegc"],
    desc: "💀 Quitte le groupe et disparaît dans l'ombre.",
    react: "👋",
    category: "owner",
    filename: __filename
},
async (conn, mek, m, { from, isGroup, sender, reply }) => {
    try {
        if (!isGroup) {
            return reply("⛔ *Cette invocation ne fonctionne que dans les cercles maudits (groupes).*");
        }

        const botOwner = conn.user.id.split(":")[0];
        if (sender !== botOwner) {
            return reply("❌ *Seul le maître des ténèbres peut ordonner mon départ.*");
        }

        await reply("⚡ *Je m'efface des lieux... Laissant derrière moi un voile de silence...*");
        await sleep(1500);
        await conn.groupLeave(from);
        await reply("👋 *Adieu, mortels. Que l'ombre vous enveloppe.*");
    } catch (e) {
        console.error("Erreur dans la commande leave:", e);
        reply(`💀 *Une erreur obscure a empêché mon départ...* \n\n${e}`);
    }
});