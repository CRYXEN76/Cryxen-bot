const config = require('../settings');
const { malvin, commands } = require('../malvin');
const axios = require("axios");

malvin({
  pattern: "didyouknow",
  react: "❓",
  alias: ["dyk", "fact", "randomfact"],
  desc: "Affiche un fait surprenant et inutile.",
  category: "fun",
  use: ".didyouknow",
  filename: __filename,
}, async (conn, mek, msg, { from, args, reply }) => {
  try {
    const response = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
    const { text } = response.data;

    const factMessage = `
╭────── ⍟ 『 𝐃𝐈𝐃 𝐘𝐎𝐔 𝐊𝐍𝐎𝐖 ? 』⍟ ──────╮

📌 *Fait Inutile mais Intéressant :*
${text}

╰──────────────⸸──────────────╯
👁️‍🗨️ *Propulsé par 𝙲𝚁𝚈𝚇𝙴𝙽 𝕏*`.trim();

    await reply(factMessage);
  } catch (error) {
    console.error("Erreur lors de la récupération :", error);
    reply("❌ Une erreur est survenue lors de la récupération du fait. Réessaie plus tard.");
  }
});