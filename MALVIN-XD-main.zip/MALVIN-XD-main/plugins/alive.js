const { malvin } = require("../malvin");
const config = require("../settings");
const { runtime } = require('../lib/functions');
const moment = require("moment");

const ALIVE_IMG = "https://files.catbox.moe/iqkzzn.jpg";

malvin({
    pattern: "alive",
    desc: "Vérifie le statut démoniaque du bot et son uptime infernal",
    category: "main",
    react: "🔥",
    filename: __filename
}, async (conn, mek, m, { reply, from }) => {
    try {
        const pushname = m.pushName || "Âme Perdue";
        const now = moment();
        const currentTime = now.format("HH:mm:ss");
        const currentDate = now.format("dddd, MMMM Do YYYY");

        const uptime = runtime(process.uptime());

        const msg = `
☠️─────☠️─────☠️─────☠️─────☠️─────
        𝕮𝖗𝖞𝖝𝖊𝖓 𝕏 • 𝔸𝕝𝕚𝕧𝕖
☠️─────☠️─────☠️─────☠️─────☠️─────

👤 *Bienvenue, ${pushname}...*  
🕰️ *Heure infernale:* ${currentTime}  
📅 *Date funeste:* ${currentDate}  
⏳ *Temps d’activité:* ${uptime}  
⚙️ *Mode:* ${config.MODE}  
🔰 *Version:* ${config.version}

──────────────────────────────  
🔥 *Le démon est éveillé et rôde.*  
💀 *CRYXEN 𝕏 ne dort jamais...*  
──────────────────────────────`;

        await conn.sendMessage(from, {
            image: { url: ALIVE_IMG },
            caption: msg
        }, { quoted: mek });

    } catch (err) {
        console.error("Error in .alive:", err);
        return reply(`❌ *⚠️ Commande Alive brisée :*\n${err.message}`);
    }
});