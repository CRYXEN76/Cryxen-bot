const { malvin } = require('../malvin');
const config = require('../settings');
const fs = require('fs');
const path = require('path');

const warnPath = path.join(__dirname, '../data/warnings.json');
let warnings = fs.existsSync(warnPath) ? JSON.parse(fs.readFileSync(warnPath)) : {};

const saveWarnings = () => {
  fs.writeFileSync(warnPath, JSON.stringify(warnings, null, 2));
};

const linkPatterns = [
  /https?:\/\/(?:chat\.whatsapp\.com|wa\.me)\/\S+/gi,
  /https?:\/\/(www\.)?whatsapp\.com\/channel\/[a-zA-Z0-9_-]+/gi,
  /https?:\/\/(?:t\.me|telegram\.me)\/\S+/gi,
  /https?:\/\/(?:www\.)?youtube\.com\/\S+/gi,
  /https?:\/\/youtu\.be\/\S+/gi,
  /https?:\/\/(?:www\.)?facebook\.com\/\S+/gi,
  /https?:\/\/fb\.me\/\S+/gi,
  /https?:\/\/(?:www\.)?instagram\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?twitter\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?tiktok\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?linkedin\.com\/\S+/gi,
  /https?:\/\/(?:www\.)?discord\.com\/\S+/gi
];

malvin({
  on: 'body'
}, async (conn, m, store, {
  from,
  body,
  sender,
  isGroup,
  isAdmins,
  isBotAdmins,
  participants
}) => {
  try {
    if (!isGroup || isAdmins || !isBotAdmins) return;

    const containsLink = linkPatterns.some(pattern => pattern.test(body));
    if (!containsLink) return;

    const whitelist = config.LINK_WHITELIST?.split(',') || [];
    const isWhitelisted = whitelist.some(link => body.includes(link));
    if (isWhitelisted) return;

    // Delete the message direct, sans pitié
    if (config.DELETE_LINKS === 'true') {
      await conn.sendMessage(from, { delete: m.key }, { quoted: m });
    }

    if (!warnings[from]) warnings[from] = {};
    if (!warnings[from][sender]) warnings[from][sender] = 0;

    warnings[from][sender]++;
    saveWarnings();

    const warnCount = warnings[from][sender];
    const limit = parseInt(config.LINK_WARN_LIMIT || 3);

    const senderName = participants.find(p => p.id === sender)?.notify || sender.split('@')[0];

    // Message d’avertissement démoniaque
    const warnMessages = [
      `💀 Attention @${senderName}, ce lien est une hérésie interdite ici !`,
      `🔥 AVERTISSEMENT ${warnCount}/${limit} — Tu joues avec le feu, @${senderName} !`,
      `☠️ Plus qu’un avertissement et l’enfer t’attend, @${senderName}... RÉCULE !`,
      `💣 TU AS DÉPASSÉ LES LIMITES, @${senderName} ! Prépare-toi à être expédié !`
    ];

    // Choix du message selon le nombre d’avertissements
    let messageToSend = warnMessages[Math.min(warnCount - 1, warnMessages.length - 1)];

    await conn.sendMessage(from, {
      text: messageToSend,
      mentions: [sender]
    });

    // Action finale si dépassement du seuil
    if (warnCount >= limit) {
      if (config.LINK_ACTION === 'kick') {
        await conn.groupParticipantsUpdate(from, [sender], 'remove');
        await conn.sendMessage(from, {
          text: `💀 ${senderName} a été PURGÉ du groupe pour avoir bravé l'interdit. 🔥`
        });
      } else if (config.LINK_ACTION === 'mute') {
        const muteDuration = 10 * 60; // 10 minutes
        const until = Math.floor(Date.now() / 1000) + muteDuration;
        await conn.groupParticipantsUpdate(from, [sender], 'restrict', { mute: until });
        await conn.sendMessage(from, {
          text: `🔇 ${senderName} est réduit au silence pour 10 minutes. Ne tente pas de revenir avant...`
        });
      }

      warnings[from][sender] = 0;
      saveWarnings();
    }

  } catch (err) {
    console.error('🔥 [ANTILINK PURGE ERROR] 🔥', err);
  }
});