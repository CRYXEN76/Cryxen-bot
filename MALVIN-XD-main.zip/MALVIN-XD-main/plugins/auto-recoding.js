const fs = require('fs');
const path = require('path');
const config = require('../settings');
const { malvin, commands } = require('../malvin');

// Auto-enregistrement démoniaque : le bot affiche qu'il "enregistre" quand quelqu'un écrit dans le groupe/chat
malvin({
  on: "body"
}, async (conn, mek, m, { from }) => {
  try {
    if (config.AUTO_RECORDING === 'true') {
      // Envoie le status "enregistrement" pour simuler une présence active intense
      await conn.sendPresenceUpdate('recording', from);
    }
  } catch (error) {
    console.error("🔥 Auto-recording error:", error);
  }
});