/*
Project Name : CRYXEN X
Creator      : CRYXEN 2109
Repo         : https://github.com/CRYXEN76/CRYXEN-X
Support      : +2250545477175
*/

const { malvin } = require('../malvin');
const config = require('../settings');

malvin({
    pattern: "user",
    react: "✅", 
    desc: "Get owner number",
    category: "main",
    filename: __filename
}, 
async (conn, mek, m, { from, reply }) => {
    try {
        const ownerNumber = config.OWNER_NUMBER; // Fetch owner number from config
        const ownerName = config.OWNER_NAME;     // Fetch owner name from config

        const vcard = 'BEGIN:VCARD\n' +
                      'VERSION:3.0\n' +
                      `FN:${ownerName}\n` +  
                      `TEL;type=CELL;type=VOICE;waid=${ownerNumber.replace('+', '')}:${ownerNumber}\n` + 
                      'END:VCARD';

        // Send the vCard contact
        await conn.sendMessage(from, {
            contacts: {
                displayName: ownerName,
                contacts: [{ vcard }]
            }
        }, { quoted: mek });

        // Send the owner contact info with image and caption
        await conn.sendMessage(from, {
            image: { url: 'https://files.catbox.moe/v1rf80.jpg' }, // Your image URL
            caption: `
╭┈┈❍ CRYXEN X ❍
┊• *Here are the user details*
┊• *ɴᴀᴍᴇ* : ${ownerName}
┊• *ɴᴜᴍʙᴇʀ*: ${ownerNumber}
┆• *ᴠᴇʀsɪᴏɴ*: ${config.version}
╰┈┈┈┈┈┈┈⭘
> © Stay connected for fantastic updates!
`,
            contextInfo: {
                mentionedJid: [`${ownerNumber.replace('+', '')}@s.whatsapp.net`], 
                forwardingScore: 999,
                isForwarded: true
            }
        }, { quoted: mek });

    } catch (error) {
        console.error(error);
        reply(`❌ An error occurred: ${error.message}`);
    }
});