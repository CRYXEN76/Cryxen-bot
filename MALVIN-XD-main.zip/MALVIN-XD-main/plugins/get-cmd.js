
const { malvin, commands } = require('../malvin');
const fs = require('fs');
const path = require('path');

malvin({
    pattern: "get",
    alias: ["source", "js"],
    desc: "Obtiens le code source d'une commande",
    category: "owner",
    react: "📜",
    filename: __filename
},
async (conn, mek, m, { from, args, reply, isOwner }) => {
    try {
        if (!isOwner) return reply("⛔ Tu n’as pas le pouvoir pour cette invocation.");
        if (!args[0]) return reply("❗ Fournis le nom d'une commande.\n\nExemple: `.get alive`");

        const commandName = args[0].toLowerCase();
        const commandData = commands.find(cmd => 
            cmd.pattern === commandName || 
            (cmd.alias && cmd.alias.includes(commandName))
        );

        if (!commandData) return reply("❌ Cette commande est introuvable dans les abysses.");

        const commandPath = commandData.filename;
        const fullCode = fs.readFileSync(commandPath, 'utf-8');

        let truncated = fullCode;
        if (truncated.length > 4000) {
            truncated = truncated.substring(0, 4000) + "\n\n// Code trop long... Envoi du fichier complet 📂";
        }

        const msg = `
╭─╼『 🧾 CODE SOURCE DEMONIAQUE 』╾─╮

\`\`\`js
${truncated}
\`\`\`

╰⛧━━━━━━━━━━━━⛧╯
🧠 *Auteur:* 𝙲𝚁𝚈𝚇𝙴𝙽²¹⁰⁹
`.trim();

        await conn.sendMessage(from, {
            image: { url: 'https://files.catbox.moe/e0kj4n.jpg' },
            caption: msg,
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 0,
                isForwarded: false
            }
        }, { quoted: mek });

        const fileName = `${commandName}.js`;
        const tempPath = path.join(__dirname, fileName);
        fs.writeFileSync(tempPath, fullCode);

        await conn.sendMessage(from, {
            document: fs.readFileSync(tempPath),
            mimetype: 'text/javascript',
            fileName: fileName
        }, { quoted: mek });

        fs.unlinkSync(tempPath);

    } catch (e) {
        console.error("Erreur .get :", e);
        reply("💥 Une erreur obscure est survenue !");
    }
});