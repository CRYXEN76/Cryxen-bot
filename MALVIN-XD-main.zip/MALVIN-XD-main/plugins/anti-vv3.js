const axios = require('axios');
const config = require('../settings');
const { malvin, commands } = require('../malvin');
const util = require("util");

malvin({
    pattern: "vv3",
    alias: ['retrive', ''],
    desc: " Invocation du Seigneur CRYXEN  : R�cup�re et renvoie le contenu maudit ViewOnce (image/vid�o/son).",
    category: "owner",
    use: '<r�ponse � message view once>',
    filename: __filename
},
async (conn, mek, m, { from, reply, isCreator }) => {
    try {
        if (!isCreator) {
            return await reply(" *Seul le Ma�tre CRYXEN  peut invoquer cette puissance.*");
        }

        const quotedMessage = m.msg.contextInfo?.quotedMessage;

        if (quotedMessage && quotedMessage.viewOnceMessageV2) {
            const quot = quotedMessage.viewOnceMessageV2;

            if (quot.message.imageMessage) {
                let cap = quot.message.imageMessage.caption || " *Image damn�e r�cup�r�e.*";
                let anu = await conn.downloadAndSaveMediaMessage(quot.message.imageMessage);
                return await conn.sendMessage(from, { image: { url: anu }, caption: cap }, { quoted: mek });
            }

            if (quot.message.videoMessage) {
                let cap = quot.message.videoMessage.caption || " *Vid�o interdite d�voil�e.*";
                let anu = await conn.downloadAndSaveMediaMessage(quot.message.videoMessage);
                return await conn.sendMessage(from, { video: { url: anu }, caption: cap }, { quoted: mek });
            }

            if (quot.message.audioMessage) {
                let anu = await conn.downloadAndSaveMediaMessage(quot.message.audioMessage);
                return await conn.sendMessage(from, { audio: { url: anu } }, { quoted: mek });
            }
        }

        // Cas message "viewOnceMessage" classique
        if (!m.quoted) return reply(" *R�ponds � un message 'view once' maudit pour briser son sceau...*");

        if (m.quoted.mtype === "viewOnceMessage") {
            if (m.quoted.message.imageMessage) {
                let cap = m.quoted.message.imageMessage.caption || " *Image damn�e r�cup�r�e.*";
                let anu = await conn.downloadAndSaveMediaMessage(m.quoted.message.imageMessage);
                return await conn.sendMessage(from, { image: { url: anu }, caption: cap }, { quoted: mek });
            } 
            else if (m.quoted.message.videoMessage) {
                let cap = m.quoted.message.videoMessage.caption || " *Vid�o interdite d�voil�e.*";
                let anu = await conn.downloadAndSaveMediaMessage(m.quoted.message.videoMessage);
                return await conn.sendMessage(from, { video: { url: anu }, caption: cap }, { quoted: mek });
            }
        } 
        else if (m.quoted.message.audioMessage) {
            let anu = await conn.downloadAndSaveMediaMessage(m.quoted.message.audioMessage);
            return await conn.sendMessage(from, { audio: { url: anu } }, { quoted: mek });
        } 
        else {
            return reply(" *Ce message n'est pas un message 'ViewOnce'.*");
        }
    } catch (e) {
        console.error(" Commande vv3 erreur fatale:", e);
        return reply(" *Erreur d�moniaque lors de la r�cup�ration du message ViewOnce.*");
    }
});