const { malvin } = require('../malvin');

malvin({
    pattern: "out",
    alias: ["ck", "🦶"],
    desc: "Expulse tous les membres d'un indicatif pays donné.",
    category: "admin",
    react: "💀",
    filename: __filename
},
async (conn, mek, m, {
    from, q, isGroup, isBotAdmins, reply, groupMetadata, senderNumber
}) => {

    if (!isGroup) return reply("🚫 *Commande réservée aux groupes infernaux.*");

    const botOwner = conn.user.id.split(":")[0];
    if (senderNumber !== botOwner) {
        return reply("🔒 *Toi... Tu n’es pas le Démon Suprême. Accès refusé.*");
    }

    if (!isBotAdmins) return reply("🪬 *Je suis enchaîné... Donne-moi les droits d’Admin.*");

    if (!q) return reply("📛 *Balance l’indicatif à purger, exemple:* `.out 92`");

    const code = q.trim();
    if (!/^\d+$/.test(code)) {
        return reply("⚠️ *Code invalide. Uniquement des chiffres autorisés.*");
    }

    try {
        const participants = groupMetadata.participants;
        const cibles = participants.filter(p =>
            p.id.startsWith(code) && !p.admin
        );

        if (cibles.length === 0) {
            return reply(`🧪 *Aucun membre avec l’indicatif +${code} trouvé. Les ombres sont calmes...*`);
        }

        const jids = cibles.map(p => p.id);
        await conn.groupParticipantsUpdate(from, jids, "remove");

        reply(`🔥 *Purification complète.*\nExpulsé(s) : ${cibles.length} âme(s) avec +${code}`);
    } catch (err) {
        console.error("⛔ Out command error:", err);
        reply("💥 *Échec de la purge. Une force s’oppose...*\n" + err.message);
    }
});