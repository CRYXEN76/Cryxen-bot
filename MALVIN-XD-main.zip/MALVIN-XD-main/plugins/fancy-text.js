const axios = require("axios");
const { malvin } = require("../malvin");

malvin({
  pattern: "fancy",
  alias: ["font", "style"],
  react: "✍️",
  desc: "Convertir un texte en plusieurs polices stylées.",
  category: "fun",
  filename: __filename
}, async (conn, m, store, { from, quoted, args, q, reply }) => {
  try {
    if (!q) {
      return reply("❌ Veuillez entrer un texte à transformer.\n\n📌 *Exemple:* .fancy CRYXEN X");
    }

    const apiUrl = `https://www.dark-yasiya-api.site/other/font?text=${encodeURIComponent(q)}`;
    const response = await axios.get(apiUrl);

    if (!response.data.status || !response.data.result) {
      return reply("⚠️ Impossible de récupérer les polices. Réessaie plus tard.");
    }

    const fonts = response.data.result
      .map(item => `╭─⫷ *${item.name}* ⫸─╮\n${item.result}`)
      .join("\n\n");

    const resultText = `
╔═════〔 𝙵𝙾𝙽𝚃𝚂 𝙳𝙴𝙼𝙾𝙽𝙸𝙰𝚀𝚄𝙴𝚂 〕═════╗

${fonts}

╚═══════⫷ 𝙲𝚁𝚈𝚇𝙴𝙽 𝕏 ⫸═══════╝
`.trim();

    await conn.sendMessage(from, { text: resultText }, { quoted: m });
  } catch (error) {
    console.error("❌ Erreur dans la commande fancy :", error);
    reply("🚫 Une erreur est survenue pendant la génération des polices.");
  }
});