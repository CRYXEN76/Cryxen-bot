const { malvin } = require('../malvin');
const config = require('../settings');
const { sleep } = require('../lib/functions2');

malvin({
  pattern: "broadcast",
  category: "group",
  desc: "Le bot envoie un message puissant à tous les groupes où il se trouve.",
  filename: __filename,
  use: "<texte à diffuser>"
}, async (conn, mek, m, { q, isGroup, isAdmins, reply }) => {
  try {
    if (!isGroup) return reply("❌ Cette commande fonctionne uniquement en groupe.");
    if (!isAdmins) return reply("❌ Seuls les admins du groupe peuvent lancer une diffusion.");

    if (!q) return reply("❌ Indique le texte à diffuser à tous les groupes.");

    const allGroups = await conn.groupFetchAllParticipating();
    const groupIds = Object.keys(allGroups);

    await reply(`📢 *CRYXEN 𝕏 BROADCAST*\nEnvoi en cours vers *${groupIds.length}* groupes...\n⏳ Patiente... L'énergie noire se déchaîne...`);

    for (const groupId of groupIds) {
      try {
        await sleep(1500); // Pause anti spam
        await conn.sendMessage(groupId, { text: `🔥 *[DIFFUSION CRYXEN]* 🔥\n\n${q}` });
      } catch (err) {
        console.error(`❌ Impossible d'envoyer au groupe ${groupId}:`, err);
      }
    }

    return reply(`✅ Diffusion terminée. Message envoyé à *${groupIds.length}* groupes. Le pouvoir est en marche.`);
  } catch (err) {
    console.error("Erreur broadcast:", err);
    reply(`❌ Une erreur est survenue lors de la diffusion :\n${err.message || err}`);
  }
});