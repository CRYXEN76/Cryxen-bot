const config = require('../settings');
const { malvin } = require('../malvin');

malvin({
    pattern: "ping",
    alias: ["speed", "pong", "ping2", "ping3"],
    use: '.ping',
    desc: "Teste la rapidité de réponse du bot.",
    category: "main",
    react: "⚡",
    filename: __filename
}, async (conn, mek, m, { from, sender, reply }) => {
    try {
        const startTime = Date.now();

        const emojis = ['🔥', '⚡', '🚀', '💨', '🎯', '💥', '🛡️', '✨'];
        const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];

        // Réaction instantanée
        await conn.sendMessage(from, {
            react: { text: randomEmoji, key: mek.key }
        });

        const ping = Date.now() - startTime;

        let badge = '🐢 Lenteur infernale';
        let color = '🔴';

        if (ping <= 150) {
            badge = '🚀 Ultra rapide';
            color = '🟢';
        } else if (ping <= 300) {
            badge = '⚡ Rapide';
            color = '🟡';
        } else if (ping <= 600) {
            badge = '⚠️ Moyenne';
            color = '🟠';
        }

        const text = `
╔══════════════════════╗
║      ⚡ 𝕮𝖗𝖞𝖝𝖊𝖓 𝕏 ⚡      
╠══════════════════════╣
║ ⏱️ Temps de réponse : *${ping} ms* ${randomEmoji}
║ ⚙️ Statut : ${color} ${badge}
║ 🛡️ Version : *${config.version}*
╚══════════════════════╝
`;

        await conn.sendMessage(from, {
            text,
            contextInfo: { mentionedJid: [sender] }
        }, { quoted: mek });

    } catch (e) {
        console.error("Erreur dans la commande ping :", e);
        reply("❌ Une erreur est survenue lors du test de rapidité.");
    }
});