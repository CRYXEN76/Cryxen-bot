const { malvin } = require('../malvin');

malvin({
    pattern: "demote",
    alias: ["d", "dismiss", "removeadmin"],
    desc: "Destitue un admin et le renvoie au rang de simple mortel",
    category: "admin",
    react: "⬇️",
    filename: __filename
},
async(conn, mek, m, {
    from, q, quoted, isCmd, isGroup, sender, botNumber, isBotAdmins, isAdmins, reply
}) => {

    if (!isGroup) return reply("❌ Cette invocation ne peut être utilisée qu'en groupe.");
    if (!isAdmins) return reply("❌ Seuls les élus du trône (admins) peuvent invoquer cette sentence.");
    if (!isBotAdmins) return reply("❌ Je dois être admin pour pouvoir frapper ce coup fatal.");

    let number;
    if (m.quoted) {
        number = m.quoted.sender.split("@")[0];
    } else if (q && q.includes("@")) {
        number = q.replace(/[@\s]/g, '');
    } else {
        return reply("❌ Mentionne ou réponds au message de la victime à destituer.");
    }

    if (number === botNumber) return reply("⛔ Je ne peux pas m'autodétruire, ô maître des ombres.");

    const jid = number + "@s.whatsapp.net";

    try {
        await conn.groupParticipantsUpdate(from, [jid], "demote");
        reply(`☠️ *Un admin vient d'être banni du trône !*\n\n🧨 @${number} est redevenu simple roturier.`, {
            mentions: [jid]
        });
    } catch (error) {
        console.error("❌ Erreur lors de la destitution :", error);
        reply("⚠️ L'exécution a échoué. Le démon résiste à la sentence.");
    }
});